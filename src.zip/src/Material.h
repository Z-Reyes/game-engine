#pragma once
/*
The material struct is simply a collection of values used for phong shading with the Z-Engine.
It consists of an array of ambient, diffuse, specular, and a shiny value
for light reflectivity.
The ambient component is the rgba for ambient light,
the diffuse is the rgba for diffuse light.
The specular component is the rgba for specular
the shiny value is for shininess.
*/
struct material {
	float ambient[4];
	float diffuse[4];
	float specular[4];
	float shiny;
	unsigned int identifier;
	material();
	void ResetIndex(int index);
	void ResetAmbient();
	void ResetDiffuse();
	void ResetSpecular();
	void ResetShiny();
	void ResetAll();
	void SetAmbient(float* aValues);
	void SetAmbient(float av1, float av2, float av3, float av4);
	void SetDiffuse(float* dValues);
	void SetDiffuse(float dv1, float dv2, float dv3, float dv4);
	void SetSpecular(float* sValues);
	void SetSpecular(float sv1, float sv2, float sv3, float sv4);
	void SetShiny(float shine);

	
};