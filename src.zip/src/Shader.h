#pragma once
#include <string>
#include <unordered_map>
#include "Z_Math.h"

//#include "glm/glm.hpp"

/*
	ShaderProgramSource is a container for the strings representing
	the Vertex shader and Fragment shader. Taken from TheChernoProject's OpenGL series
*/
struct ShaderProgramSource {
	std::string VertexSource;
	std::string FragmentSource;
};

/*
	The Shader class is a container used for tracking shaders to be used. They are used by the RenderManager
	for rendering.
	Most of the code for this class came from TheChernoProject's OpenGL tutorial series.
*/
class Shader
{
private:
	std::string m_FilePath;
	unsigned int m_RendererID;
	//caching for uniforms
	std::unordered_map<std::string, int> m_UniformLocationCache;
public:
	/*
	Builds a Shader from the .shader file specified by filepath.
	*/
	Shader(const std::string& filepath);
	/*
	Deletes this shader from the program and removes shader from OpenGL
	*/
	~Shader();

	/*
	Binds the shader for rendering.
	*/
	void Bind() const;
	/*
	Unbinds the shader.
	*/
	void Unbind() const;
	/*
	Gets the OpenGL ID of this shader.
	*/
	unsigned int GetmID();
	/*
	Sets the tier of this shader. Should not be used except for when creating the shader (which is done automatically).
	*/
	void SetTier(unsigned int val);
	/*
	Returns the tier of this shader.
	*/
	unsigned int GetTier();

	//Set uniforms
	/*
	Sets an integer uniform value. name is the identifier of the variable name in the shader, value is the desired
	value of that variable.
	*/
	void SetUniform1i(const std::string& name, int value);
	/*
	Sets a 4 float uniform value. name is the identifier of the variable name in the shader, v0 is the first desired value,
	v1 is the second, v2 is the third, v3 is the fourth.
	*/
	void SetUniform4f(const std::string& name, float v0, float v1, float v2, float v3);
	/*
	Sets a Uniform Mat4 matrix. name is the identifier of the variable name in the shader. matrix is the desired matrix
	of that variable.
	*/
	void SetUniformMat4f(const std::string& name, Zat4& matrix);
	void SetUniform3fv(const std::string& name, const float*  in);
	void SetUniform4fv(const std::string& name, const float*  in);
	void SetUniform1f(const std::string& name, const float in);
private:
	/*
	Used for properly parsing shaders so they can be used for OpenGL
	*/
	ShaderProgramSource ParseShader(const std::string& filepath);
	/*
	Compiles the parsed shaders for openGL usage.
	*/
	unsigned int CompileShader(unsigned int type, const std::string& source);
	/*
	Creates shader in OpenGL.
	*/
	unsigned int CreateShader(const std::string& vertexShader, const std::string& fragmentShader);
	/*
	Returns the unsigned int identifier for a given variable name.
	*/
	unsigned int GetUniformLocation(const std::string& name);
	/*
	Represents the tier of this particular shader. Used in RenderManager to determine how advanced the rendering of an object is.
	*/
	unsigned int tier;
};
