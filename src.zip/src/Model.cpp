#include "Model.h"

void Model::AppendShape(RenderableShape* append)
{
	shapeQueue.push_back(append);
	numberShapes++;
}

int Model::GetNumShapes()
{
	return numberShapes;
}

RenderableShape* Model::GetShapeAtIndex(int index)
{
	if (index < numberShapes) {
		return shapeQueue.at(index);
	}
	else {
		return nullptr;
	}
}

void Model::LoadModelViaAssimp(std::string filepath)
{
	
	Assimp::Importer importer;
	const aiScene *scene = importer.ReadFile(filepath, aiProcess_Triangulate);
	std::cout << "Loading file via assimp" << std::endl;
	//const aiScene *scene = importer.ReadFile(filepath, aiProcessPreset_TargetRealtime_MaxQuality);
	if (!scene || scene->mFlags & AI_SCENE_FLAGS_INCOMPLETE || !scene->mRootNode)
	{
		//Means we will never be able to render the object
		std::cout << "ERROR::ASSIMP::" << importer.GetErrorString() << std::endl;
		isRenderable = false;
		return;
	}
	std::string directory = filepath.substr(0, filepath.find_last_of('/'));
	isRenderable = true;
	//Now, we simply iterate through the meshes, building a new renderable object for each one.
	//After running through the process, we append the meshes onto the shape list.
	unsigned int size = scene->mNumMeshes;
	//std::cout << "Number of meshes is " << size << std::endl;
	std::vector<std::string>* loadedTextures = new std::vector<std::string>();
	std::vector <std::string>* textureNames = new std::vector<std::string>();
	std::cout << "Halfway point" << std::endl;
	for (int i = 0; i < size; i++) {
		//std::cout << "READING the " << i << "th mesh" << std::endl;
		AppendShape(new RenderableShape(directory, scene, scene->mMeshes[i], loadedTextures, textureNames));
	}
	delete loadedTextures;
	delete textureNames;
	std::cout << "Finished reading" << std::endl;
}

bool Model::GetIsRenderable()
{
	return isRenderable;
}

Model::Model()
{
	numberShapes = 0;
	isRenderable = true;
}

Model::~Model()
{
	for (int i = 0; i < numberShapes; i++) {
		delete shapeQueue.at(i);
	}
}
