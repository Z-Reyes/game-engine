#include "Stationary_Object.h"

Stationary_Object::Stationary_Object()
{
}

Stationary_Object::Stationary_Object(float x, float y, float z, unsigned int dt)
{
	//x, y, and z are starting positions.
	SetDesiredTier(dt);
	SetScale(1.0f, 1.0f, 1.0f);
	if (dt == 1) {
		SetShaderID("default_T1_shader");
	}
	else if (dt == 2) {
		SetShaderID("default_T2_shader");
	}
	else {
		SetShaderID("default_T3_shader");
	}
	SetTexID("default_texture");
	SetShapeID("Cube");

	SetPosition(x, y, z);
	SetRotation(Zec3(0.0f, 1.0f, 0.0f), 0.0f);
	SetUseMyTexture(false);
	usePhysics = false;
	friction = 1.0f;
	restitution = 0.0f;
	mass = 1.0f;

}

void Stationary_Object::OnUpdate()
{
	//if we use physics, we update our location and rotation.
	ApplyPhysicsChanges();
}
