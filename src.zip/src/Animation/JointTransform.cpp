#include "JointTransform.h"

Zat4 JointTransform::GetLocalTransform()
{
	return QuaternionToRM(myRotation) * Translate(myPosition);
	//return Translate(myPosition) * QuaternionToRM(myRotation);
}

Zec3  JointTransform::GetMyPosition()
{
	return myPosition;
}

Quaternion JointTransform::GetMyRotation()
{
	return myRotation;
}

JointTransform::JointTransform(Zec3 pos, Quaternion rot)
{
	myPosition = pos;
	myRotation = rot;
}

JointTransform Interpolate(JointTransform * frameA, JointTransform * frameB, float progression)
{
	Zec3 newPos = Lerp(frameA->GetMyPosition(), frameB->GetMyPosition(), progression);
	Quaternion rot = Lerp(frameA->GetMyRotation(), frameB->GetMyRotation(), progression);
	return JointTransform(newPos, rot);
}
