#pragma once
#include "Animated_Model.h"
#include "Animation.h"
#include <unordered_map>
class Animator {
private:
	Animated_Model * entity;
	Animation * currentAnimation;
	float animationTime;
	void IncreaseAnimationTime(float delta);
	std::unordered_map<std::string, Zat4> CalculateCurrentAnimationPose();
	float CalculateProgression(KeyFrame * curr, KeyFrame *next);
	int GetPreviousAndNextFrames();
	std::unordered_map<std::string, Zat4> InterpolatePoses(KeyFrame* prevFrame, KeyFrame * nextFrame, float progression);


	void ApplyPoseToJoints(std::unordered_map<std::string, Zat4> currP, Joint * j, Zat4 in); // recursive algorithm
public:
	Animator(Animated_Model * entity);
	void doAnimation(Animation * ani);

	void UpdateAnimation(float delta);
	
};