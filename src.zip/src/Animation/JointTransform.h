#pragma once
#include "Z_Math.h"
class JointTransform {
private:
	Quaternion myRotation;
	Zec3 myPosition; // Keep an eye out for this.

public:
	Zat4 GetLocalTransform();
	Zec3  GetMyPosition();
	Quaternion GetMyRotation();
	JointTransform(Zec3 pos, Quaternion rot);
};

JointTransform Interpolate(JointTransform* frameA, JointTransform * frameB, float progreesion);