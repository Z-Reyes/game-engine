#pragma once
#include "Joint.h"
//#include "Animator.h"
#include "Animation.h"
#include "Renderable_Shape.h"
/*
The use of a single array for storing all components is difficult to read at this point. It would be helpful
to use other structs within a model to store the values and then convert that into an array after processing is completed.

That's what the Animated_Model class is used for. It is similar to the RenderableObject class, with the following exceptions:
1. A single mesh and a skeleton are associated with one another. This means we can have one set of vertices associated with one skeleton, at least for now.
Maybe in the future I will add the ability to associated more than one mesh with a single skeleton. It does not sound complicated, just a little more work.

2. Every vertex can have a maximum of 3 joints that are weighted for them.

3. Animated_Model class objects are required to have a skeleton. They should not be used with any model that does not have a skeleton, that should be saved for
a basic Renderable_Object.

4. It is assumed that the inverse matrix is provided by the collada file (Animated_Model at this point only reads collada).

5. Animated_Models have their own set of tier shaders. They are equivalent to the static tier 1 - 3 Renderable_Object models (vertex only, vertex-texture, vertex-texture-material).
*/

class Animated_Model {

private:
	Joint* rootJoint;
	int jointCount;
	RenderableShape* myShape;
	Zat4* myJointTransforms;
	std::string myTexture;
	//Need animator
	//Animator* myAnimator;
	void AddJointsToArray(Joint* headJoint, Zat4* jointMatrices);
public:
	Animated_Model(RenderableShape *shape, std::string texID, Joint* root, int jc);
	Joint* GetRootJoint();
	int GetJointCount();
	RenderableShape * GetMyShape();
	std::string GetMyString();
	Zat4* GetJointTransforms();
	//void SetMyAnimator(Animator* inAnimator);
	~Animated_Model();
	//void Update();
	//void DoAnimation(Animation animation);

};