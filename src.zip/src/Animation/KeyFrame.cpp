#include "KeyFrame.h"

KeyFrame::KeyFrame(float time, std::unordered_map<std::string, JointTransform*> jointKeyFrames)
{
	timeStamp = time;
	pose = jointKeyFrames;
}

std::unordered_map<std::string, JointTransform*> KeyFrame::GetJointKeyFrames()
{
	return pose;
}

float KeyFrame::GetTimeStamp()
{
	return timeStamp;
}
