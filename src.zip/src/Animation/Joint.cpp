#include "Joint.h"

Joint::Joint(int id, std::string jName, Zat4 bindLocalTransform)
{
	identifier = id;
	name = jName;
	animation_transform = bindLocalTransform;
}

Joint::~Joint()
{
}

void Joint::AddChild(Joint * child)
{
	children.push_back(child);
}

Joint * Joint::GetChildAt(int index)
{
	if (index < GetChildrenSize()) {
		return children.at(index);
	}
	else {
		std::cout << "Size is too large. Cannot return value" << std::endl;
		return nullptr;
	}
}

int Joint::GetChildrenSize()
{
	return children.size();
}

void Joint::SetAnimationTransform(Zat4 anitransform)
{
	animation_transform = anitransform;
}

Zat4  Joint::GetAnimationTransform()
{
	return animation_transform;
}

void Joint::SetBindTransform(Zat4 bTransform)
{
	bind_transform = bTransform;
}

Zat4  Joint::GetBindTransform()
{
	return bind_transform;
}

void Joint::SetInverseBindTransform(Zat4 ibTransform)
{
	inverse_bind_transform = ibTransform;
}

Zat4  Joint::GetInverseBindTransform()
{
	return inverse_bind_transform;
}
