#pragma once
#include <vector>
#include "KeyFrame.h"
/*
A container of keyframes that are used by an animator for the purposes of animating a mesh.
*/
class Animation {
private:
	float animationLength;
	std::vector<KeyFrame> keyFrames;

public:
	~Animation();
	float GetLength();
	Animation(float lengthInSeconds, std::vector<KeyFrame> frames);
	std::vector<KeyFrame>* GetKeyFrames();
};