#include "Animated_Model.h"

void Animated_Model::AddJointsToArray(Joint * headJoint, Zat4 * jointMatrices)
{
	jointMatrices[headJoint->identifier] = headJoint->GetAnimationTransform();
	int mySize = headJoint->GetChildrenSize();

	for (int i = 0; i < mySize; i++) {
		AddJointsToArray(headJoint->GetChildAt(i), jointMatrices);
	}
}

Animated_Model::Animated_Model(RenderableShape * shape, std::string texID, Joint* root, int jc)
{
	rootJoint = root;
	jointCount = jc;
	myTexture = texID;
	myShape = shape;
	myJointTransforms = new Zat4[jc];
	//rootJoint.calcInverseBindTransform(new Matrix4f());

}

Joint * Animated_Model::GetRootJoint()
{
	return rootJoint;
}

int Animated_Model::GetJointCount()
{
	return jointCount;
}

RenderableShape * Animated_Model::GetMyShape()
{
	return myShape;
}

std::string Animated_Model::GetMyString()
{
	return myTexture;
}

Zat4 * Animated_Model::GetJointTransforms()
{
	//Zat4* jointMatrices = new Zat4[jointCount];
	AddJointsToArray(rootJoint, myJointTransforms);
	return myJointTransforms;

}
/*
void Animated_Model::SetMyAnimator(Animator * inAnimator)
{
	myAnimator = inAnimator;
}
*/
Animated_Model::~Animated_Model()
{
}
/*
void Animated_Model::Update()
{
	myAnimator->UpdateAnimation();
}
*/

