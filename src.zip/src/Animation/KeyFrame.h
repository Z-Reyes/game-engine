#pragma once
#include <unordered_map>
#include "JointTransform.h"
#include <string>
class KeyFrame {
private:
	float timeStamp;
	std::unordered_map<std::string, JointTransform*> pose;

public:
	KeyFrame(float time, std::unordered_map<std::string, JointTransform*> jointKeyFrames);
	std::unordered_map<std::string, JointTransform*> GetJointKeyFrames();
	float GetTimeStamp();
};