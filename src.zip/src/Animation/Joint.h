#pragma once
#include <vector>
#include <string>
#include "Z_Math.h"
class Joint {
public:
	int identifier;
	std::string name;

	Joint(int id, std::string jName, Zat4 bindLocalTransform); //bindLocalTransform used for bind_transform
	~Joint();
	void AddChild(Joint * child);
	Joint* GetChildAt(int index);
	int GetChildrenSize();
	void SetAnimationTransform(Zat4 anitransform);
	Zat4 GetAnimationTransform();

	void SetBindTransform(Zat4 bTransform);
	Zat4 GetBindTransform();
	void SetInverseBindTransform(Zat4 ibTransform);
	Zat4  GetInverseBindTransform();
private:
	std::vector<Joint*> children;
	Zat4 animation_transform;
	Zat4 bind_transform;
	Zat4 inverse_bind_transform;
};