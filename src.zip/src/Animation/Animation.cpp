#include "Animation.h"

Animation::~Animation()
{
}

float Animation::GetLength()
{
	return animationLength;
}

Animation::Animation(float lengthInSeconds, std::vector<KeyFrame> frames)
{
	animationLength = lengthInSeconds;
	keyFrames = frames;
}

std::vector<KeyFrame>* Animation::GetKeyFrames()
{
	return &keyFrames;
}
