#include "Animator.h"

void Animator::IncreaseAnimationTime(float delta)
{
	animationTime += delta; // this is bad but I gotta do it rn. Later I can change it to the actual frame rate.
	if (animationTime > currentAnimation->GetLength()) {
		while (animationTime > currentAnimation->GetLength()) {
			animationTime = animationTime - currentAnimation->GetLength();
		}

	}
}

std::unordered_map<std::string, Zat4> Animator::CalculateCurrentAnimationPose()
{
	//return std::unordered_map<std::string, Zat4>();
	//KeyFrame** frames = GetPreviousAndNextFrames(); //I will give this a try but it'll be the first point I look at if things break badly.
	int location = GetPreviousAndNextFrames();
	//std::cout << "Here we go, location is " << location << std::endl;
	std::vector<KeyFrame> * myKeyFrames = currentAnimation->GetKeyFrames();
	float progression = CalculateProgression(&myKeyFrames->at(location), &myKeyFrames->at(location + 1));
	return InterpolatePoses(&myKeyFrames->at(location), &myKeyFrames->at(location + 1), progression);
}

float Animator::CalculateProgression(KeyFrame* curr, KeyFrame* next)
{
	float totalTime = next->GetTimeStamp() - curr->GetTimeStamp();
	//std::cout << "total time is " << totalTime << std::endl;
	float currentTime = animationTime - curr->GetTimeStamp();
	return currentTime / totalTime;
}

int Animator::GetPreviousAndNextFrames()
{
	std::vector<KeyFrame> * myKeyFrames = currentAnimation->GetKeyFrames();
	int prevFrameLocation = 0;
	int nextFrameLocation = 0;
	KeyFrame previousFrame = myKeyFrames->at(prevFrameLocation);
	KeyFrame nextFrame = myKeyFrames->at(nextFrameLocation);
	int frameSize = myKeyFrames->size();
	for (int i = 1; i < frameSize; i++) {
		nextFrame = myKeyFrames->at(i);
		nextFrameLocation = i;
		if (nextFrame.GetTimeStamp() > animationTime) {
			break;
		}
		previousFrame = myKeyFrames->at(i);
		prevFrameLocation = i;
	}

	//KeyFrame * list[2] = { &myKeyFrames->at(prevFrameLocation), &myKeyFrames->at(nextFrameLocation) };
	//return list; // Probably going to cause issues.
	return prevFrameLocation;

}

std::unordered_map<std::string, Zat4> Animator::InterpolatePoses(KeyFrame * prevFrame, KeyFrame * nextFrame, float progression)
{
	std::unordered_map<std::string, Zat4> currentPose;

	/*
	Assistance from https://thispointer.com/how-to-iterate-over-an-unordered_map-in-c11/
	*/
	for (std::pair<std::string, JointTransform*> element : prevFrame->GetJointKeyFrames()) { //This loop is incorrect. The list is empty at the start. I think it should be for each pair an existing pair in the KeyFrame vector.
		JointTransform* previousTransform = prevFrame->GetJointKeyFrames().at(element.first);
		JointTransform* nextTransform = nextFrame->GetJointKeyFrames().at(element.first);
		JointTransform currentTransform = Interpolate(previousTransform, nextTransform, progression);
		currentPose.insert({ element.first, currentTransform.GetLocalTransform() });
	}
	return currentPose;
}

void Animator::ApplyPoseToJoints(std::unordered_map<std::string, Zat4> currP, Joint * j, Zat4 in)
{
	Zat4 currentLocalTransform = currP.at(j->name); //This is supposed to be in bone space
	Zat4 currentWorldTransform = in * currentLocalTransform;
	int numJchildren = j->GetChildrenSize();
	for (int i = 0; i < numJchildren; i++) {
		ApplyPoseToJoints(currP, j->GetChildAt(i), currentWorldTransform); // This is expecting some type of reference I think, might need to change arguments.
	}
	Zat4 finalTransform = j->GetInverseBindTransform() * currentWorldTransform; //Might need to swap order of multiplication.
	j->SetAnimationTransform(finalTransform);
}

Animator::Animator(Animated_Model * inEntity)
{
	entity = inEntity;
}

void Animator::doAnimation(Animation * ani)
{
	animationTime = 0.0f;
	currentAnimation = ani;
}

void Animator::UpdateAnimation(float delta)
{
	if (currentAnimation == nullptr) {
		return;
	}
	IncreaseAnimationTime(delta);
	std::unordered_map <std::string, Zat4> currPos = CalculateCurrentAnimationPose();
	ApplyPoseToJoints(currPos, entity->GetRootJoint(), Zat4(1.0f));

}
