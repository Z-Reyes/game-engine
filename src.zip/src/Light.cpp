#include "Light.h"
#include <iostream>
light::light()
{
	float baseValue = 0.75f;
	SetAmbient(baseValue, baseValue, baseValue);
	SetDiffuse(baseValue, baseValue, baseValue);
	SetSpecular(baseValue, baseValue, baseValue);
	SetCLQ(baseValue, baseValue, baseValue);
	ambientLight[3] = 1.0f;
	diffuseLight[3] = 1.0f;
	specularLight[3] = 1.0f;
	ambientAura[3] = 1.0f;
}

void light::SetAura(float * auraValues)
{
	//if (sizeof(auraValues) / sizeof(float) == 3) {
		ambientAura[0] = auraValues[0];
		ambientAura[1] = auraValues[1];
		ambientAura[2] = auraValues[2];
		//ambientLight[3] = aValues[3];
	//}
	//else {
		//Do nothing
	//}
}

void light::SetAura(float auraV1, float auraV2, float auraV3)
{
	ambientAura[0] = auraV1;
	ambientAura[1] = auraV2;
	ambientAura[2] = auraV3;
}

void light::SetAmbient(float * aValues)
{
	//int size = sizeof(aValues) / sizeof(aValues[0]);
	//std::cout << "Size of aValues / aValues[0] is " << size << std::endl;
	//if (sizeof(aValues) / sizeof(aValues[0]) == 3) {
		ambientLight[0] = aValues[0];
		ambientLight[1] = aValues[1];
		ambientLight[2] = aValues[2];
		//ambientLight[3] = aValues[3];
	//}
	//else {
		//Do nothing
	//}
}

void light::SetAmbient(float av1, float av2, float av3)
{
	float ambientValues[3];
	ambientValues[0] = av1;
	ambientValues[1] = av2;
	ambientValues[2] = av3;
	SetAmbient(ambientValues);
}

void light::SetDiffuse(float * dValues)
{
	//if (sizeof(dValues) / sizeof(float) == 3) {
		diffuseLight[0] = dValues[0];
		diffuseLight[1] = dValues[1];
		diffuseLight[2] = dValues[2];
	//	diffuse[3] = dValues[3];
	//}
	//else {
		//Do nothing
	//}
}

void light::SetDiffuse(float dv1, float dv2, float dv3)
{
	float diffuseValues[3];
	diffuseValues[0] = dv1;
	diffuseValues[1] = dv2;
	diffuseValues[2] = dv3;
	SetDiffuse(diffuseValues);
}

void light::SetSpecular(float * sValues)
{
	//if (sizeof(sValues) / sizeof(float) == 3) {
		specularLight[0] = sValues[0];
		specularLight[1] = sValues[1];
		specularLight[2] = sValues[2];
		//specular[3] = sValues[3];
	//}
	//else {
		//Do nothing
	//}
}

void light::SetSpecular(float sv1, float sv2, float sv3)
{
	float specularValues[3];
	specularValues[0] = sv1;
	specularValues[1] = sv2;
	specularValues[2] = sv3;
	SetSpecular(specularValues);
}

void light::SetPosition(float * pValues)
{
	//if (sizeof(pValues) / sizeof(float) == 3) {
		position[0] = pValues[0];
		position[1] = pValues[1];
		position[2] = pValues[2];
		//specular[3] = sValues[3];
	//}
	//else {
		//Do nothing
	//}
}

void light::SetPosition(float pv1, float pv2, float pv3)
{
	//float positionValues[3];
	position[0] = pv1;
	position[1] = pv2;
	position[2] = pv3;
	//SetSpecular(positionValues);
}

void light::SetConstant(float constantIn)
{
	constant = constantIn;
}

void light::SetLinear(float linearIn)
{
	linear = linearIn;
}

void light::SetQuadratic(float quadraticIn)
{
	quadratic = quadraticIn;
}

void light::SetCLQ(float constantIn, float linearIn, float quadraticIn)
{
	SetConstant(constantIn);
	SetLinear(linearIn);
	SetQuadratic(quadraticIn);
}
