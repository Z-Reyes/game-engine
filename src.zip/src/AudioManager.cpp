#include "AudioManager.h"
#include <iostream>
AudioManager* AudioManager::singletonAM = nullptr;
AudioManager::AudioManager()
{
}

AudioManager::~AudioManager()
{
	if (!soundList.empty()) {
		soundList.clear();
	}
}

AudioManager * AudioManager::getAudioManager()
{
	/*
	Singleton structure used from https://www.geeksforgeeks.org/singleton-design-pattern/
	*/
	if (singletonAM == nullptr) {
		static AudioManager audManager;
		singletonAM = &audManager;
	}
	return singletonAM;
}

void AudioManager::InsertAudio(std::string identifer, std::string filepath)
{
	if (isStarted) {
		soundList.insert({ identifer, new AudioSource(filepath) });
	}
}

AudioSource * AudioManager::GetAudioWithId(std::string identifier)
{
	if (isStarted) {
		AudioSource* potential = soundList.at(identifier);
		if (potential != nullptr || potential->GetState() != AL_NO_ERROR) {
			return potential;
		}
		else {
			return nullptr;
		}
	}
}

void AudioManager::Startup()
{
	alutInit(0, NULL);
	//alDistanceModel(AL_EXPONENT_DISTANCE);
	std::cout << alutGetErrorString(alGetError()) << std::endl;
	isStarted = true;
}

void AudioManager::Shutdown()
{
	// Taken from: https://isocpp.org/blog/2016/08/quick-q-unordered-map-element-being-deleted
	for (auto iter = soundList.begin(); iter != soundList.end(); iter++) {
		AudioSource* val = iter->second;
		delete val;
		}
	soundList.clear();
	ALboolean alutExit(void);
	isStarted = false;
}

AudioManager * CreateStaticAM()
{
	return AudioManager::getAudioManager();
}
