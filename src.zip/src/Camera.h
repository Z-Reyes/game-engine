#pragma once
#include "Z_Math.h"

class Camera {

public:
	static float incX, incY, incZ, rX, rY, rZ;
	Camera();
	~Camera();
	//void SetKeyIn();
	//void SetWindow(GLFWwindow *inwin);

	void MoveCameraX();
	void MoveCameraY();
	void MoveCameraZ();
	void ReCalculateRightVector();
	void ReCalculateForwardVector();
	void ReCalculateUpVector();
	void ReCalculateAllVectors();
	void RCameraX();
	void RCameraY();
	void RCameraZ();
	void AssignAllChanges();
	void ResetStaticValues();
	Zat4 GetTRMatrix();
	Zos GetCameraLocation();
	Zec3 GetForwardVector();
	Zec3 GetUpVector();
private:
	Zos cameraLocation;
	Zec3 currRotation, forwardVector, rightVector, upVector; //currRotation is in angles 0 degrees = 0.0f, 90 degrees = 90.0f.
};