#pragma once
#include "AudioSource.h"
#include "alut.h"
#include <unordered_map>
#include <string>
class AudioManager {
private:
	static AudioManager* singletonAM;
	AudioManager();
	~AudioManager();
	bool isStarted = false;
	std::unordered_map<std::string, AudioSource* > soundList;
public:
	static AudioManager* getAudioManager();
	void InsertAudio(std::string identifer, std::string filepath);
	AudioSource * GetAudioWithId(std::string identifier);
	void Startup();
	void Shutdown();

};

AudioManager* CreateStaticAM();