#pragma once
/*
This header file is simply a collection of assertions to allow us 
to do gl error checking with each gl call.
All assertions and definition statements in this file came from TheChernoProject's OpenGL series.
*/
#include <GL/glew.h>

#define ASSERT(x) if (!(x)) __debugbreak();
#define GLCall(x) GLClearError();\
	x;\
	ASSERT(GLLogCall(#x, __FILE__, __LINE__))

void GLClearError();
bool GLLogCall(const char* function, const char* file, int line);