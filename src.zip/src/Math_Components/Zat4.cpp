#include "Zat4.h"

Zat4::Zat4()
{
	ClearMatrix();
	//mat[0] = 1.0f;
	//mat[5] = 1.0f;
	//mat[10] = 1.0f;
	mat[15] = 1.0f;
}

Zat4::Zat4(float con)
{
	ClearMatrix();
	mat[0] = con;
	mat[5] = con;
	mat[10] = con;
	mat[15] = 1.0f;
}

Zat4::Zat4(float rc11, float rc22, float rc33)
{
	ClearMatrix();
	mat[0] = rc11;
	mat[5] = rc22;
	mat[10] = rc33;
	mat[15] = 1.0f;
}



Zat4::~Zat4()
{
}
void Zat4::AddAtLocation(float in, int index) {
	if (index > 15 || index < 0) {
		//Do nothing.
	}
	else {
		mat[index] += in;
	}
}

std::string Zat4::PrintMatrixValues()
{
	std::string out = "";
	//out = out + std::to_string(0.0f);
	out = out + "\n["; // +std::to_string(mat[0]);
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			int columnNum = j * 4;
			out = out + std::to_string(mat[i + columnNum]) + ", ";
		}
		if (i == 3) {
			out = out + "]";
		}
		out = out + "\n";
	}
	return out;
}

float * Zat4::GetMatrix() {
	return mat;
}
void Zat4::ClearMatrix() {
	for (int j = 0; j < 16; j++) {
		mat[j] = 0.0f;
	}
}




