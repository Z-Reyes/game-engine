#pragma once
#include "PositionBag.h"
#include <string>
/*
The Quaternion class is designed for Quaternion operations, such as rotation and rotational lerping.
It relies on the Position_Bag struct for storing its relevant values.
Specification for which value is which is within the PositionBag.h file.
*/
class Quaternion {
private: Position_Bag quad;

public:
	/*
		Initialize a Quaternion with 4 starting values. Currently the constructor does not ensure that
		the resulting quaternion follows the Mag(quaternion) = 1 condition.
	*/
	Quaternion(float x, float y, float z, float w);
	/*
	Initialize a blank quaternion with only a w value equal to 1.
	*/
	Quaternion();
	/*
	Return a reference to this class's Position_Bag
	*/
	Position_Bag* getQuad();
	/*
	The ToString method returns the values for each component of this quaternion as a string to be used in debugging purposes.
	*/
	std::string ToString();

};