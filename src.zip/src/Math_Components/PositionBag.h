#pragma once
/*
The unfortunately named Position_Bag struct is our container for values
for the Quaternion, Zec3, and Zos classes.
Each of the 3 aforementioned classes rely on this struct for storing relevant information.
In general, we want to obsfucate this struct away from the developer so they aren't working with it directly.
For Zec3 and Zos: location[0] = x coordinate, location[1] = y coordinate, location[2] = z coordinate, location[3] = w coordinate.
For Quaternion: location[0] = x coordinate, location[1] = y coordinate, location[2] = z coordinate, location[3] = real coordinate.
*/
struct Position_Bag {
	//location[0] = x
	//location[1] = y
	//location[2] = z
	//location[3] = w
	float location[4];
	//Use default values
	Position_Bag() {
		location[0] = 0.0f;
		location[1] = 0.0f;
		location[2] = 0.0f;
		location[3] = 0.0f;
	}
	//Initialize values for Position_Bag.
	Position_Bag(float x, float y, float z, float w) {
		location[0] = x;
		location[1] = y;
		location[2] = z;
		location[3] = w;
	}
};