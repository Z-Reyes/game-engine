#pragma once
#include "PositionBag.h"
#include <string>
/*
	The Zec3 class is a class representing 3D vectors in space. It relies on the Position_Bag struct for storing its values.
	Specifications for how the Position_Bag struct's layout is for this class can be found in PositionBag.h
*/
class Zec3 {

private:
	Position_Bag vec3;

public:
	/*
	Return a Zec3 with no coordinates specified.
	Values are defaulted to 0.
	*/
	Zec3();
	~Zec3();
	/*
	Return a Zec3 with x, y, z coordinates specified.
	*/
	Zec3(float x1, float y1, float z1);
	/*
	Return a Zec3 with x, y, z, w coordinates specified.
	Needs to be removed at some point.
	*/
	Zec3(float x1, float y1, float z1, float w1);
	/*
	Return a reference to this class's Position_Bag
	*/
	Position_Bag* GetDirection();
	/*
	Produces a string of the coordinate values (not including w).
	*/
	std::string ToString();

};