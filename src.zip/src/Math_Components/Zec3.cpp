#include "Zec3.h"

Zec3::Zec3()
{

	vec3.location[0] = 0.0f;
	vec3.location[1] = 0.0f;
	vec3.location[2] = 0.0f;
	vec3.location[3] = 0.0f;
}

Zec3::~Zec3()
{
}

Zec3::Zec3(float x1, float y1, float z1)
{
	vec3.location[0] = x1;
	vec3.location[1] = y1;
	vec3.location[2] = z1;
	vec3.location[3] = 0.0f;
}
Zec3::Zec3(float x1, float y1, float z1, float w1) {
	vec3.location[0] = x1;
	vec3.location[1] = y1;
	vec3.location[2] = z1;
	vec3.location[3] = w1;
}

Position_Bag* Zec3::GetDirection()
{
	return &vec3;
}

std::string Zec3::ToString()
{
	std::string out = "ZEC: [ " + std::to_string(vec3.location[0]) + " ";
	out += std::to_string(vec3.location[1]) + " ";
	out += std::to_string(vec3.location[2]) + " ] ";
		return out;
}
