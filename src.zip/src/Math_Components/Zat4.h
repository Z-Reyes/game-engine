#pragma once
#include <string>
/*
	The Zat4 class is our class for 4x4 matrices. For maximum compatibility with OpenGL, it stores its values in a single-array
	using column major ordering.
*/
class Zat4 {
private:
	float mat[16];
public:
	/*
	Initialize the Zat4 with default 0 values.
	*/
	Zat4();
	/*
	Initialize the Zat4 with con value along the diagonal.
	*/
	Zat4(float con);
	/*
	Clear values 0-14 of the matrix back to 0.
	*/
	void ClearMatrix();
	/*
	Initialize the Zat4 with [1,1], [2,2], and [3,3] initialized using the 3 arguments, respectively.
	*/
	Zat4(float rc11, float rc22, float rc33);

	/*
	Adds the value of in at the index specified.
	*/
	void AddAtLocation(float in, int index);
	/*
	A ToString() method that returns a string of the matrix values for easy viewing and debugging.
	*/
	std::string PrintMatrixValues();
	/*
	Returns a pointer to our matrix.
	*/
	float * GetMatrix();
	~Zat4();
};

