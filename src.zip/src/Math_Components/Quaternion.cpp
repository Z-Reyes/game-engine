#include "Quaternion.h"

Quaternion::Quaternion(float x, float y, float z, float w)
{
	quad.location[0] = x;
	quad.location[1] = y;
	quad.location[2] = z;
	quad.location[3] = w;
}

Quaternion::Quaternion()
{
	quad.location[0] = 0.0f;
	quad.location[1] = 0.0f;
	quad.location[2] = 0.0f;
	quad.location[3] = 1.0f;
}

Position_Bag * Quaternion::getQuad()
{
	return &quad;
}

std::string Quaternion::ToString()
{
	std::string out = "[";
	out += std::to_string(quad.location[0]);
	out += ", ";
	out += std::to_string(quad.location[1]);
	out += ", ";
	out += std::to_string(quad.location[2]);
	out += ", ";
	out += std::to_string(quad.location[3]);
	out += "] ";
		return out;
}
