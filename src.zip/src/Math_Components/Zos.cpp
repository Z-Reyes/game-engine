#include "Zos.h"

Zos::Zos()
{
	position.location[0] = 0.0f;
	position.location[1] = 0.0f;
	position.location[2] = 0.0f;
	position.location[3] = 1.0f;
}

Zos::Zos(float x1, float y1, float z1)
{
	position.location[0] = x1;
	position.location[1] = y1;
	position.location[2] = z1;
	position.location[3] = 1.0f;
}

Zos::~Zos()
{

}

Position_Bag * Zos::GetPosition()
{

	return &position;
}
std::string Zos::ToString()
{
	std::string out = "Zos: [ " + std::to_string(position.location[0]) + " ";
	out += std::to_string(position.location[1]) + " ";
	out += std::to_string(position.location[2]) + " ] ";
	return out;
}
