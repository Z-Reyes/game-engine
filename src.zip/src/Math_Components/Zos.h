#pragma once
#include "PositionBag.h"
#include <string>
/*
The "Zos" class is a class that is supposed to represent points in 3D space.
It has 2 constructors, one that initiates its position values to 0, and one where the developer
can specify each position's starting value.
Specifications for how the Position_Bag struct's layout is for this class can be found in PositionBag.h
*/
class Zos {
private:
	Position_Bag position;

public:
	/*
	Initialize a Zos with no coordinates specified.
	Values are defaulted to 0.
	*/
	Zos();
	/*
		Initialize a Zos with the x, y, z coordinates specified.
	*/
	Zos(float x1, float y1, float z1);
	~Zos();
	/*
	Return a reference to this class's Position_Bag
	*/
	Position_Bag* GetPosition();
	/*
	Produces a string of the coordinate values (not including w).
	*/
	std::string ToString();
};