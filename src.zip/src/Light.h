#pragma once

/*
The light struct is for a positional light for lighting of a model.
*/
enum typeOfLight {directional, positional, spot};
struct light {
	float ambientAura[4]; //Overall ambient color.
	float ambientLight[4];
	float diffuseLight[4];
	float specularLight[4];
	float position[3];
	unsigned int identifier;
	enum typeOfLight myType;

	float constant, linear, quadratic;
	light();
	void SetAura(float *auraValues);
	void SetAura(float auraV1, float auraV2, float auraV3);
	void SetAmbient(float * aValues);
	void SetAmbient(float av1, float av2, float av3);
	void SetDiffuse(float * dValues);
	void SetDiffuse(float dv1, float dv2, float dv3);
	void SetSpecular(float * sValues);
	void SetSpecular(float sv1, float sv2, float sv3);
	void SetPosition(float *pValues);
	void SetPosition(float pv1, float pv2, float pv3);
	void SetConstant(float constantIn);
	void SetLinear(float linearIn);
	void SetQuadratic(float quadraticIn);
	void SetCLQ(float constantIn, float linearIn, float quadraticIn);
};