#include "Camera.h"

float Camera::incX, Camera::incY, Camera::incZ, Camera::rX, Camera::rY, Camera::rZ = 0.0f;

Camera::Camera()
{
	cameraLocation = Zos(0.0f, 0.0f, 0.0f);
	currRotation = Zec3(0.0f, 0.0f, 0.0f); //Rotation will eventually need to be replaced with a quaternion.
	rightVector = Zec3(1.0f, 0.0f, 0.0f);
	forwardVector = Zec3(0.0f, 0.0f, 1.0f);
	upVector = Zec3(0.0f, 1.0f, 0.0f);
	//currentWindow = inwin;
	//SetKeyIn();
}
//We need to calculate new right vector
void Camera::ReCalculateRightVector() {
	float y = currRotation.GetDirection()->location[1];
	Position_Bag* rv = rightVector.GetDirection();
	rv->location[0] = cos(y); //gonna assume degrees need to become radians
	rv->location[1] = 0.0f;
	rv->location[2] = -sin(y); //gonna assume degrees need to become radians
											  //std::cout << currRotation.y << std::endl;
											  //std::cout << "( " << rightVector.x << ", " << rightVector.z << " )" << std::endl;
}
void Camera::ReCalculateForwardVector() {
	Position_Bag *rotation_bag = currRotation.GetDirection();
	float x = rotation_bag->location[0];
	float y = rotation_bag->location[1];
	Position_Bag *fv = forwardVector.GetDirection();
	if (rotation_bag->location[0] <= -1.5707) {
		rotation_bag->location[0] = -1.5707;
	}
	else if (rotation_bag->location[0] >= 1.5707) {
		rotation_bag->location[0] = 1.5707;
	}
	//if (currRotation.y >= 1.5707) {
	//	currRotation.y = 1.5707;
	//}
	//else if (currRotation.y <= -1.5707) {
	//	currRotation.y = -1.5707;
	//}


	fv->location[0] = -((-sin(y)) * cos(x));
	fv->location[1] = -(-sin(x));
	fv->location[2] = -((-cos(x)) * cos(y));
	//std::cout << "forward is " << forwardVector.ToString() << std::endl;
	//std::cout << "( " << forwardVector.x << ", " << forwardVector.y << ", " << forwardVector.z << " )" << std::endl;

}
void Camera::ReCalculateUpVector() {
	upVector = Cross( rightVector, forwardVector);
}
void Camera::ReCalculateAllVectors() {
	Camera::ReCalculateRightVector();
	Camera::ReCalculateForwardVector();
	Camera::ReCalculateUpVector();
}

Camera::~Camera()
{
}
//void Camera::SetWindow(GLFWwindow *inwin) {
//	currentWindow = inwin;
//	SetKeyIn();
//}

void Camera::MoveCameraX()
{
	cameraLocation = cameraLocation + (incX * rightVector);//(rightVector * (1.0f + incX));
}

void Camera::MoveCameraY()
{
	cameraLocation = cameraLocation + ( incY * upVector);//(upVector * (1.0f + incY));
}

void Camera::MoveCameraZ()
{
	cameraLocation = cameraLocation + (incZ * forwardVector);//(forwardVector * (1.0f + incZ));
}
void Camera::RCameraX()
{
	currRotation.GetDirection()->location[0] += rX;
}

void Camera::RCameraY()
{
	currRotation.GetDirection()->location[1] += rY;
}

void Camera::RCameraZ()
{
	currRotation.GetDirection()->location[2] += rZ;
}
//void Camera::SetKeyIn() {
//	glfwSetKeyCallback(currentWindow, key_callback);
//}
void Camera::AssignAllChanges() {


	RCameraX();
	RCameraY();
	RCameraZ();
	ReCalculateAllVectors();
	MoveCameraX();
	MoveCameraY();
	MoveCameraZ();
	//std::cout << "Forward is: " << forwardVector.ToString() << std::endl;
	//std::cout << "Right is: " << rightVector.ToString() << std::endl;
	//std::cout << "Up is:" << upVector.ToString() << std::endl;
}
Zat4 Camera::GetTRMatrix() {
	Position_Bag* cLocation = cameraLocation.GetPosition();
	//std::cout << "x value is: " << cameraLocation.x << std::endl;
	return      Rotate(rightVector, -currRotation.GetDirection()->location[0]) * Rotate( upVector, -currRotation.GetDirection()->location[1]) * Translate( cLocation->location[0], cLocation->location[1], cLocation->location[2]);
}

Zos Camera::GetCameraLocation()
{
	return cameraLocation;
}

Zec3 Camera::GetForwardVector()
{
	return forwardVector;
}

Zec3 Camera::GetUpVector()
{
	return upVector;
}

void Camera::ResetStaticValues() {
	Camera::incX, Camera::incY, Camera::incZ, Camera::rX, Camera::rY, Camera::rZ = 0.0f;
}


