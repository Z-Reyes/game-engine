#pragma once
#include "PhysicsHeaders.h"
#include "Renderable_Object.h"
//#include "Renderable_Object.h"
enum RigidBodyPrimitive { Sphere, Cube, Plane, Cylinder, Capsule, Cone };

class PhysicsManager {
public:
	void StartUp();
	void Shutdown();
	static PhysicsManager* getPhysicsManager();
	void UpdateWorld(float delta);
	void InsertRigidBody(RendereableObject* thisObject, RigidBodyPrimitive typeofrb);
	//void UpdateRigidBodyValues(RendereableObject* thisObject);
private:
	static PhysicsManager* singletonPM;
	bool isStarted;
	btDiscreteDynamicsWorld* dynamicsWorld;
	btDefaultCollisionConfiguration* collisionConfiguration;
	btCollisionDispatcher * dispatcher;
	btBroadphaseInterface* overlappingPairCache;
	btSequentialImpulseConstraintSolver* solver;
	btAlignedObjectArray<btCollisionShape*> collisionShapes;
};

PhysicsManager * CreateStaticPM();