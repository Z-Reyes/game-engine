#include "Renderable_Object.h"

bool RendereableObject::isRenderable()
{
	return false;
}

void RendereableObject::Translation_Rotation_Order_set(bool tr)
{
	trans_first = tr;
}

void RendereableObject::Set_Parent_T_Rotation_Order(bool pTr)
{
	parent_trans_first = pTr;
}

void RendereableObject::Use_Parent_Translation(bool usePT)
{
	use_parent_trans = usePT;
}

void RendereableObject::Use_Parent_Rotation(bool usePR)
{
	use_parent_rotation = usePR;
}

void RendereableObject::Set_Self_Changes_First(bool sf)
{
	self_first = sf;
}

int RendereableObject::IsRenderable()
{
	return 0; //Doesn't do anything at this point.
}

void RendereableObject::SetDesiredTier(unsigned int dt)
{
	desiredTier = dt;
}

void RendereableObject::SetShaderID(std::string sID)
{
	shader_id = sID;
}

void RendereableObject::SetShapeID(std::string shID)
{
	shape_id = shID;
}

void RendereableObject::SetTexID(std::string tID)
{
	texture_id = tID;
	SetUseMyTexture(true);
}

unsigned int RendereableObject::GetDesiredTier()
{
	return desiredTier;
}

std::string RendereableObject::GetShaderID()
{
	return shader_id;
}

std::string RendereableObject::GetShapeID()
{
	return shape_id;
}

std::string RendereableObject::GetTexID()
{
	return texture_id;
}

void RendereableObject::SetPosition(float x, float y, float z)
{
	Position_Bag* currpos = position.GetPosition();
	currpos->location[0] = x;
	currpos->location[1] = y;
	currpos->location[2] = z;
}

void RendereableObject::SetScale(float xs, float ys, float zs)
{
	scaleX = xs;
	scaleY = ys;
	scaleZ = zs;
}

void RendereableObject::SetRotation(Zec3 axis, float radians)
{
	curr_rotation = Rotate(axis, radians);
}

Zat4 RendereableObject::ProduceModelMatrix()
{
	//For right now we're just doing rotation -> translation -> scale
	//return Zat4(scaleX, scaleY, scaleZ) * Translate(position) * curr_rotation;
	return Translate(position) * curr_rotation * Zat4(scaleX,scaleY,scaleZ);
}

Position_Bag * RendereableObject::GetPosition()
{
	return position.GetPosition();
}

float RendereableObject::GetScaleX()
{
	return scaleX;
}

float RendereableObject::GetScaleY()
{
	return scaleY;
}

float RendereableObject::GetScaleZ()
{
	return scaleZ;
}

void RendereableObject::SetUseMyTexture(bool t)
{
	useMyTexture = t;
}

bool RendereableObject::GetUseMyTexture()
{
	return useMyTexture;
}

material* RendereableObject::GetMyMaterial()
{
	return &mMaterial;
}

void RendereableObject::SetMyMaterial(material mat)
{
	mMaterial = mat;
}
/*
Change the rigid body's components automatically. Specifically, mass, restitution, and friction.
*/
void RendereableObject::UpdateRigidBodyValues()
{
	if (myBody) {
		myBody->setRestitution(restitution);
		myBody->setFriction(friction);
		myBody->applyCentralForce(btVector3(initialForce.location[0], initialForce.location[1], initialForce.location[2]));
	}
}

void RendereableObject::ApplyPhysicsChanges()
{
	if (usePhysics) {

		if (myBody) {
			btTransform trans;
			//if (myBody && myBody->getMotionState()) {
				myBody->getMotionState()->getWorldTransform(trans);
			//}
			//else {
				//trans = myObj->getWorldTransform();
			//}
			SetPosition(float(trans.getOrigin().getX()), float(trans.getOrigin().getY()), float(trans.getOrigin().getZ()));
			//std::cout << "x, y, and z "
			//trans.getRotation().x
			curr_rotation = QuaternionToRM(Quaternion(float(-trans.getRotation().x()), float(-trans.getRotation().y()), float(-trans.getRotation().z()), float(trans.getRotation().w())));
		}
	}
}

void RendereableObject::ForceObjectPositionOnPhysics()
{
	//Code help from: https://gamedev.stackexchange.com/questions/58689/how-to-set-the-objects-world-position-in-bullet
	//myBody->activate(true);

	//myBody->applyCentralForce(btVector3(0.0f, 0.0f, -1.0f));
	//btTransform tempTrans =  myBody->getWorldTransform();
	//myBody->translate()
	//tempTrans.setOrigin(btVector3(position.GetPosition()->location[0], position.GetPosition()->location[1], position.GetPosition()->location[2]));
	//tempTrans.Set
// Assistance from https://stackoverflow.com/questions/12251199/re-positioning-a-rigid-body-in-bullet-physics
	/*
	btTransform transform;
	transform.setIdentity();
	Position_Bag *myPos = GetPosition();
	transform.setOrigin(btVector3(myPos->location[0], myPos->location[1], myPos->location[2]));
	myBody->getMotionState()->setWorldTransform(transform);

	myBody->setLinearVelocity(btVector3(0.0f, 0.0f, 0.0f));
	myBody->setAngularVelocity(btVector3(0.0f, 0.0f, 0.0f));
	myBody->clearForces();
	if (myBody->isStaticOrKinematicObject()) {
		std::cout << "Yo we changed status" << std::endl;
	}
	*/
	btTransform myTransform = myBody->getWorldTransform();
	float xp = myTransform.getOrigin().getX();
	float yp = myTransform.getOrigin().getY();
	float zp = myTransform.getOrigin().getZ();
	Position_Bag *myPos = GetPosition();
	//std::cout << x1 << std::endl;
	Zec3 translateVector = Zos(myPos->location[0], myPos->location[1], myPos->location[2]) - Zos(xp, yp, zp);
	Position_Bag* finalDirection = translateVector.GetDirection();
	myBody->activate(true);
	myBody->clearForces();
	
	myBody->setAngularVelocity(btVector3(0.0f, 0.0f, 0.0f));
	myBody->translate(btVector3(finalDirection->location[0], finalDirection->location[1], finalDirection->location[2]));
	myBody->setLinearVelocity(btVector3(initialForce.location[0],initialForce.location[1],initialForce.location[2]));
	//

}

void RendereableObject::PhysicsRotationCalculate()
{
	//curr_rotation = QuaternionToRM(myRotation);
}
