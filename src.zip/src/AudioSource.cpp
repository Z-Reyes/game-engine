#include "AudioSource.h"
#include <iostream>;
AudioSource::AudioSource(std::string filePath)
{
	buffer = alutCreateBufferFromFile(filePath.c_str());
	alGenSources(1, &source);
	alSourcei(source, AL_BUFFER, buffer);
	//std::cout << alutGetErrorString(alGetError()) << std::endl;
	state = alGetError();
}

AudioSource::~AudioSource()
{
	alDeleteSources(1, &source);
	alDeleteBuffers(1, &buffer);
}

void AudioSource::PlayAudio()
{
	alSourcePlay(source);
	//std::cout << alutGetErrorString(alGetError()) << std::endl;
}

void AudioSource::PauseAudio()
{
	alSourcePause(source);
	//std::cout << alutGetErrorString(alGetError()) << std::endl;
}

void AudioSource::SetPosition(float x, float y, float z)
{
	alSource3f(source, AL_POSITION, x, y, z);
	//std::cout << alutGetErrorString(alGetError()) << std::endl;
}

void AudioSource::SetPitch(float pitch)
{
	alSourcef(source, AL_PITCH, pitch);
	//std::cout << alutGetErrorString(alGetError()) << std::endl;
}

void AudioSource::SetGain(float gains)
{
	alSourcef(source, AL_GAIN, gains);
	//std::cout << alutGetErrorString(alGetError()) << std::endl;
}

void AudioSource::SetLooping(bool loop)
{
	if (loop) {
		alSourcei(source, AL_LOOPING, 1);
		//std::cout << alutGetErrorString(alGetError()) << std::endl;
	}
	else {
		alSourcei(source, AL_LOOPING, 0);
		//std::cout << alutGetErrorString(alGetError()) << std::endl;
	}
}

void AudioSource::SetFallOffFactor(float falloff)
{
	alSourcef(source, AL_ROLLOFF_FACTOR,falloff);
}

bool AudioSource::GetIsPlaying()
{
//Taken from https://www.gamedev.net/forums/topic/518057-openal----retrieve-truefalse-if-source-is-playing/

	ALenum stateTemp;

	alGetSourcei(source, AL_SOURCE_STATE, &stateTemp);

	return (stateTemp == AL_PLAYING);
}

void AudioSource::SetVelocity(float vx, float vy, float vz)
{
	alSource3f(source, AL_VELOCITY, vx, vy, vz);
	//std::cout << alutGetErrorString(alGetError()) << std::endl;
}

void AudioSource::StopAudio()
{
	alSourceStop(source);
	//std::cout << alutGetErrorString(alGetError()) << std::endl;
}

void AudioSource::SetMinDistance(float minDistance)
{
	if (minDistance >= 1.0f) {
		alSourcef(source, AL_REFERENCE_DISTANCE, minDistance);
		//std::cout << alutGetErrorString(alGetError()) << std::endl;
	}
}

void AudioSource::SetMaxDistance(float maxDistance)
{
	if (maxDistance >= 1.0f) {
		alSourcef(source, AL_MAX_DISTANCE, maxDistance);
		//std::cout << alutGetErrorString(alGetError()) << std::endl;
	}
}

void AudioSource::SetMinGain(float normalizedMin)
{
	if (normalizedMin > 0.0f && normalizedMin <= 1.0f) {
		alSourcef(source, AL_MIN_GAIN, normalizedMin);
		//std::cout << alutGetErrorString(alGetError()) << std::endl;
	}
}

void AudioSource::SetMaxGain(float normalizedMax)
{
	if (normalizedMax > 0.0f && normalizedMax <= 1.0f) {
		alSourcef(source, AL_MAX_GAIN, normalizedMax);
		//std::cout << alutGetErrorString(alGetError()) << std::endl;
	}
}

void AudioSource::ForceMaximumMaxDistance()
{
	alSourcef(source, AL_MAX_DISTANCE, FLT_MAX);
	//std::cout << alutGetErrorString(alGetError()) << std::endl;
}

ALenum AudioSource::GetState()
{
	return state;
}
