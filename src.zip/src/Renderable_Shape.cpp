#include "Renderable_Shape.h"
#include "Memory_Manager.h"

RenderableShape::RenderableShape(std::string filepath, bool useAssimp)
{
	if (!useAssimp) {
		ReadZshapeFile(filepath);
	}
	else {
		//LoadViaAssimp(filepath);
	}


}

RenderableShape::RenderableShape()
{
}
/*
Used to force allComponents to the forceAllComponents array. Used at this point for animations.
*/

RenderableShape::RenderableShape(float * forceAllComponents, unsigned int inSize, unsigned int * inIndex, unsigned int inNumVertices, unsigned int * jointIds, unsigned int jointIdSize)
{
	allComponents = forceAllComponents;
	indexPositions = inIndex;
	//Now, we load the vao with the data.
	GLCall(glGenVertexArrays(1, &shape_vao));
	GLCall(glBindVertexArray(shape_vao));

	unsigned int size = inSize;
	GLCall(glGenBuffers(1, &shape_vbo));
	GLCall(glBindBuffer(GL_ARRAY_BUFFER, shape_vbo));
	GLCall(glBufferData(GL_ARRAY_BUFFER, size * sizeof(float), allComponents, GL_STATIC_READ));

	/*
	Enable vertex array attributes.
	*/

	GLCall(glEnableVertexAttribArray(0));
	GLCall(glEnableVertexAttribArray(1));
	numVertices = inNumVertices;
	unsigned int dataSize = 6;

		GLCall(glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 4 * dataSize, 0));

	
		GLCall(glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 4 * dataSize, (const void*)12));

		GLCall(glGenBuffers(1, &vbo2));
		GLCall(glBindBuffer(GL_ARRAY_BUFFER, vbo2));
		GLCall(glBufferData(GL_ARRAY_BUFFER, jointIdSize * sizeof(unsigned int), jointIds, GL_STATIC_DRAW));
		GLCall(glEnableVertexAttribArray(2));
		//GLCall(glVertexAttribIPointer(2, 3, GL_INT, GL_FALSE, 3 * 4  , (const void*)0));
		
		GLCall(glVertexAttribIPointer(2,3,GL_UNSIGNED_INT,  3 * 4, 0));
		//GLCall(glUnbind(vbo2));
		GLCall(glGenBuffers(1, &shape_ibo));
		GLCall(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shape_ibo));
		GLCall(glBufferData(GL_ELEMENT_ARRAY_BUFFER, numVertices * sizeof(unsigned int), indexPositions, GL_STATIC_DRAW));
}


void RenderableShape::ReadZshapeFile(std::string filepath) {
	std::string lines;
	mesh_texture = "default_texture";
	
	std::ifstream openFile(filepath);
	if (!openFile) {
		tier = 0; //Means we will never be able to render the object
		std::cout << "File could not be found" << std::endl;
	}
	else {
		directory = filepath.substr(0, filepath.find_last_of('/'));
		if (getline(openFile, lines)) {
			tier = std::stoi(lines);
			//std::cout << "tier is: " << tier << std::endl;
		}
		std::vector<float> values[4];
		int fillLocation = 0;

		while (getline(openFile, lines)) {

			if (lines.find("#Positions") != std::string::npos) {
				//std::cout << "Fill location is: " << fillLocation << std::endl;
				fillLocation = 0;
			}
			else if (lines.find("#Textures") != std::string::npos) {
				fillLocation = 1;
			}
			else if (lines.find("#Normals") != std::string::npos) {
				fillLocation = 2;
			}
			else if (lines.find("#Indices") != std::string::npos) {
				fillLocation = 3;
			}
			else {
				//Now we split the string and we're good.
				//Some assistance from https://stackoverflow.com/questions/289347/using-strtok-with-a-stdstring
				std::string splitString = "";
				std::istringstream iss(lines);
				while (getline(iss, splitString, ' ')) {
					//std::cout << "Currently evaluated number is: " << splitString << "end" << std::endl;
					if (splitString.compare(" ")) {
						values[fillLocation].push_back(std::stof(splitString));
					}
					//std::cout << "Added the value " << values[fillLocation].back() << std::endl;

				}
			}

		}
		//std::cout << "Finished reading the file" << std::endl;

		//Now we check the actual tier.
		GLCall(glGenVertexArrays(1, &shape_vao));
		GLCall(glBindVertexArray(shape_vao));
		numVertices = values[0].size() / 3;
		int dataSize = 0;
		int size = 0;
		unsigned int testTier = 1;
		dataSize = 3;
		int testDataSize = 0;
		//std::cout << numVertices << " " << values[1].size() / 2 << std::endl;
		//std::cout << "Texture coordinates: " << std::endl;
		///for (int i = 0; i < values[1].size(); i++) {

		//	if (i % 2 == 0 && i != 0) {
		//		std::cout << std::endl;
		//	}
		//	std::cout << values[1].at(i) << " ";


		//}
		if (numVertices == values[1].size() / 2) {
			testTier = 2;
			testDataSize = 5;
			if (numVertices == values[2].size() / 3) {
				//std::cout << "number of normals match number of vertices" << std::endl;
				testTier = 3;
				testDataSize = 8;
			}
			else {
				//std::cout << "number of normals does not match number of vertices" << std::endl;
			}

		}

		if (tier > testTier) {
			tier = testTier;
			dataSize = testDataSize;
		}
		if (tier == 2) {
			dataSize = 5;
		}
		else if (tier == 3) {
			dataSize = 8;
		}

		//Now we fill the data as much as possible.
		if (tier >= 1) {
			int pSize = values[0].size();
			size += pSize;
			positions = new float[pSize];
			for (int i = 0; i < pSize; i++) {
				positions[i] = values[0].at(i);
				//size++;
			}
		}

		if (tier >= 2) {
			int pSize = values[1].size();
			size += pSize;
			tex_positions = new float[pSize];
			for (int i = 0; i < pSize; i++) {
				tex_positions[i] = values[1].at(i);
				//size++;
			}
		}

		if (tier >= 3) {
			int pSize = values[2].size();
			size += pSize;
			normals = new float[pSize];
			for (int i = 0; i < pSize; i++) {
				normals[i] = values[2].at(i);
				//	size++;
			}
		}
		allComponents = new float[size];

		int componentCounter = 0;
		//for (int i = 1; i <= tier; i++) {
		//	int value_size = values[i - 1].size();
		//	for (int j = 0; j < value_size; j++) {
		//		allComponents[componentCounter] = values[i - 1].at(j);
		//		componentCounter++;
		//	}
		//}
		for (int i = 0; i < numVertices; i++) {
			int position_base = i * 3;
			allComponents[componentCounter++] = values[0].at(position_base);
			allComponents[componentCounter++] = values[0].at(position_base + 1);
			allComponents[componentCounter++] = values[0].at(position_base + 2);
			if (tier >= 2) {
				int texturebase = i * 2;
				allComponents[componentCounter++] = values[1].at(texturebase);
				allComponents[componentCounter++] = values[1].at(texturebase + 1);
			}
			if (tier >= 3) {
				int normalbase = i * 3;
				allComponents[componentCounter++] = values[2].at(normalbase);
				allComponents[componentCounter++] = values[2].at(normalbase + 1);
				allComponents[componentCounter++] = values[2].at(normalbase + 2);
			}
		}
		//	std::cout << "Size is " << size << std::endl;
		//	for (int i = 0; i < size; i++) {
		//		if (i % 8 == 0) {
		//			std::cout << std::endl;
		//		}
		//		std::cout << allComponents[i] << " ";
		//	}

		//This is not very efficient code but I'm tired.
		GLCall(glGenBuffers(1, &shape_vbo));
		GLCall(glBindBuffer(GL_ARRAY_BUFFER, shape_vbo));
		GLCall(glBufferData(GL_ARRAY_BUFFER, size * sizeof(float), allComponents, GL_STATIC_READ));
		for (int k = 0; k < tier; k++) {
			GLCall(glEnableVertexAttribArray(k));

		}

		if (tier >= 1) {
			GLCall(glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 4 * dataSize, 0));
		}
		if (tier >= 2) {
			GLCall(glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * dataSize, (const void*)12));
		}

		if (tier >= 3) {
			GLCall(glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 4 * dataSize, (const void*)20));
		}

		//Finally, we take our indexPositions and fill it up.
		int numIndices = values[3].size();
		//std::cout << "NumIndices is " << numIndices << std::endl;
		if (numIndices == 0) {
			indexPositions = new unsigned int[numVertices];
			//then we fill up the values ourselves.
			//if (!values[3].empty()) {
			//	std::cout << "The number of vertices did not match!" << std::endl;
			//}
			for (int i = 0; i < numVertices; i++) {
				indexPositions[i] = (unsigned int)i;
			}
		}
		else {
			numVertices = numIndices;
			indexPositions = new unsigned int[numVertices];
			for (int i = 0; i < numVertices; i++) {
				indexPositions[i] = (unsigned int)values[3].at(i);
			}
		}

		GLCall(glGenBuffers(1, &shape_ibo));
		GLCall(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shape_ibo));
		GLCall(glBufferData(GL_ELEMENT_ARRAY_BUFFER, numVertices * sizeof(unsigned int), indexPositions, GL_STATIC_DRAW));

		//std::cout << "Tier value is " << tier << std::endl;
		//Now, we just store them in a new vao and vbo layout.
	}
	//Format of internal files.
	//1. Tier at top. First element.
	//2. #Vertices. Means the following data is for Zec3 vertices (pairs of 3).
	//3. #texture. means the following data is for texture coordinates (2D).
	//4. #Normals. Means the following data is for normal vectors (pairs of 3).

	//First, attempt to open file. If cannot, die or something.
	//Second, read information. Stop as soon as problem occurs. Tier is set to the highest successful transferred information.
	//third, transfer successful data to positions, textures, normals.
	//fourth, create a vao, specify vbo layout and data.

	//Now, to draw the shape, we just need to switch vaos, and since this shape has the vao associated with this shape, that's all we need.
	//
}
/*
Used for loading a file via assimp. I followed the model loading tutorial on learnopengl.com to do this part.
*/
RenderableShape::RenderableShape(std::string fileloc, const aiScene * scene, aiMesh *mesh, std::vector<std::string> *loadT, std::vector<std::string> *texN) {
	/*
	Assimp::Importer importer;
	const aiScene *scene = importer.ReadFile(filepath, aiProcess_Triangulate | aiProcess_FlipUVs);
	std::cout << "Loading file via assimp" << std::endl;
	//const aiScene *scene = importer.ReadFile(filepath, aiProcessPreset_TargetRealtime_MaxQuality);
	if (!scene || scene->mFlags & AI_SCENE_FLAGS_INCOMPLETE || !scene->mRootNode)
	{
		//Means we will never be able to render the object
		std::cout << "ERROR::ASSIMP::" << importer.GetErrorString() << std::endl;
		tier = 0;
		return;
	}
	directory = filepath.substr(0, filepath.find_last_of('/'));
	*/
	//Right now, we just want to process one mesh from the rootNode.
	//aiNode *testroot = scene->mRootNode;
	//aiMesh *mesh = scene->mMeshes[0];
	//unsigned int test = scene->mNumMeshes;
	mesh_texture = "default_texture";
	directory = fileloc;
	std::vector<float> values[4]; //change to values[3] for new materials.

	//Guess this is how we load the vertices.
	//std::cout << mesh->mNumVertices << std::endl;
	for (unsigned int i = 0; i < mesh->mNumVertices; i++) {
		values[0].push_back(mesh->mVertices[i].x);
		//std::cout << mesh->mVertices[i].x << std::endl;
		values[0].push_back(mesh->mVertices[i].y);
		//std::cout << mesh->mVertices[i].y << std::endl;
		values[0].push_back(mesh->mVertices[i].z);
		//std::cout << mesh->mVertices[i].z << std::endl;
	}
	tier = 1;
	int dataSize = 3;
	int textureCoordinateSize = 0;
	if (mesh->mTextureCoords[0]) {
		tier = 2;
		dataSize = 5;
		//std::cout << "Starting texture loop " << std::endl;
		for (unsigned int i = 0; i < mesh->mNumVertices; i++) {
			values[1].push_back(mesh->mTextureCoords[0][i].x);
			values[1].push_back(mesh->mTextureCoords[0][i].y);
			//std::cout << mesh->mVertices[i].y << std::endl;
			//values[0].push_back(mesh->mVertices[i].z);
			//std::cout << mesh->mVertices[i].z << std::endl;
			textureCoordinateSize += 2;
		}
		
		if (mesh->mNormals) {
			tier = 3;
			dataSize = 8;
		//	std::cout << "Starting normal loop " << std::endl;
			for (unsigned int i = 0; i < mesh->mNumVertices; i++) {
				values[2].push_back(mesh->mNormals[i].x);
				//std::cout << mesh->mVertices[i].x << std::endl;
				values[2].push_back(mesh->mNormals[i].y);
				//std::cout << mesh->mVertices[i].y << std::endl;
				values[2].push_back(mesh->mNormals[i].z);
				//std::cout << mesh->mVertices[i].z << std::endl;
			}
		}


	}

	for (unsigned int i = 0; i < mesh->mNumFaces; i++) {
		aiFace face = mesh->mFaces[i];
		for (unsigned int j = 0; j < face.mNumIndices; j++) {
			values[3].push_back(face.mIndices[j]);
		}
	}

	


	
	int size = values[0].size() + values[1].size() + values[2].size();
	//std::cout << "Size is " << size << std::endl;
	allComponents = new float[size];


	numVertices = values[0].size() / 3;
	//std::cout << "Num vertices is " << numVertices << std::endl;
	//std::cout << "Num coordinates is " << textureCoordinateSize/2 << std::endl;
	//std::cout << "Size values[0] is " << values[0].size() << std::endl;
	//std::cout << "Size values[1] is " << values[1].size() << std::endl;
	//std::cout << "Integer size is " << size << std::endl;
	int componentCounter = 0;
	for (int i = 0; i < numVertices; i++) {
		int position_base = i * 3;
		//std::string output = "";
		allComponents[componentCounter++] = values[0].at(position_base);
		//output += std::to_string(values[0].at(position_base)) + " ";
		allComponents[componentCounter++] = values[0].at(position_base + 1);
		//output += std::to_string(values[0].at(position_base+1)) + " ";
		allComponents[componentCounter++] = values[0].at(position_base + 2);
		//output += std::to_string(values[0].at(position_base+2));
		//std::cout << output << std::endl;

		if (tier >= 2) {
			int texturebase = i * 2;
			allComponents[componentCounter++] = values[1].at(texturebase);
			allComponents[componentCounter++] = values[1].at(texturebase + 1);
		//	std::cout << "Component counter is " << componentCounter << std::endl;
		}
		if (tier >= 3) {
			int normalbase = i * 3;
			allComponents[componentCounter++] = values[2].at(normalbase);
			allComponents[componentCounter++] = values[2].at(normalbase + 1);
			allComponents[componentCounter++] = values[2].at(normalbase + 2);
		}
	}
	//std::cout << "I have reached the end of packing" << std::endl;
	
	//for (int i = 0; i < size; i++) {
	//	if (i % 3 == 0) {
	//		std::cout << std::endl;
	//	}
	//	std::cout << allComponents[i] << " ";
	//}
	//std::cout << "size is " << std::endl;
	
	//std::cout << "num vertices is " << mesh->mNumVertices << std::endl;

	
	
	GLCall(glGenVertexArrays(1, &shape_vao));
	GLCall(glBindVertexArray(shape_vao));

	GLCall(glGenBuffers(1, &shape_vbo));
	GLCall(glBindBuffer(GL_ARRAY_BUFFER, shape_vbo));
	GLCall(glBufferData(GL_ARRAY_BUFFER, size * sizeof(float), allComponents, GL_STATIC_READ));
	
	for (int k = 0; k < tier; k++) {
		GLCall(glEnableVertexAttribArray(k));

	}

	if (tier >= 1) {
		GLCall(glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 4 * dataSize, 0));
	}
	if (tier >= 2) {
		GLCall(glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * dataSize, (const void*)12));
	}

	if (tier >= 3) {
		GLCall(glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 4 * dataSize, (const void*)20));
	}


	//GLCall(glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 4 * dataSize, 0));


	int numIndices = values[3].size();
	//numIndices = 0;
		//std::cout << "NumIndices is " << numIndices << std::endl;
	//then we fill up the values ourselves.

	
	if (numIndices == 0) {
		indexPositions = new unsigned int[numVertices];
		//then we fill up the values ourselves.
		//if (!values[3].empty()) {
		//	std::cout << "The number of vertices did not match!" << std::endl;
		//}
		for (int i = 0; i < numVertices; i++) {
			indexPositions[i] = (unsigned int)i;
		}
	}
	else {
		numVertices = numIndices;
		indexPositions = new unsigned int[numVertices];
		for (int i = 0; i < numVertices; i++) {
			indexPositions[i] = (unsigned int)values[3].at(i);
		}
	}

	
	GLCall(glGenBuffers(1, &shape_ibo));
	GLCall(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shape_ibo));
	GLCall(glBufferData(GL_ELEMENT_ARRAY_BUFFER, numVertices * sizeof(unsigned int), indexPositions, GL_STATIC_DRAW));

	//Now, we're going to load any possible textures we can.

	if (mesh->mMaterialIndex >= 0) { //if any materials exist.
		aiMaterial *material = scene->mMaterials[mesh->mMaterialIndex];
		ImportTextureIntoMemory(material, aiTextureType_DIFFUSE, "texture_diffuse", loadT, texN);
	}


}

void RenderableShape::ImportTextureIntoMemory(aiMaterial *mat, aiTextureType type, std::string typeName, std::vector<std::string>* loadedTextures, std::vector<std::string>* textureNames) {
	MemoryManager *mm = MemoryManager::getMemoryManager();

		for (unsigned int i = 0; i < mat->GetTextureCount(type); i++) {
			aiString str;
			mat->GetTexture(type, i, &str);
			//std::cout << "str is " << str.C_Str() << std::endl;
			//std::cout << "directory is " << directory << std::endl;
			std::string finalDestination = directory + "/" + str.C_Str();
			//Check finaldestination for appearance in loadedTextures
			int texLocation = -1;
			for (int i = 0; i < loadedTextures->size(); i++) {
				if (loadedTextures->at(i) == finalDestination) {
				//	std::cout << "We found a duplicate." << std::endl;
					texLocation = i;
				}
			}
			//std::cout << "Does this have a newline? " << finalDestination;
			//std::cout << "final file destination: " << finalDestination << std::endl;
			std::string textureName = "Texture" + std::to_string(mm->GetAutoTexture());
			if (texLocation == -1) {
				//std::cout << "Texture name is " << textureName << std::endl;
				mm->AddTexture(finalDestination, textureName);
				mm->IncrementAutoTexture();
				loadedTextures->push_back(finalDestination);
				textureNames->push_back(textureName);
			}
			else {
				textureName = textureNames->at(texLocation);
			}
			mesh_texture = textureName;


		}
}

std::string RenderableShape::GetShapeTexture()
{
	return mesh_texture;
}

RenderableShape::~RenderableShape()
{
	if (positions != NULL) {
		delete[] positions;
	}
	if (tex_positions != NULL) {
		delete[] tex_positions;
	}
	if (normals != NULL) {
		delete[] normals;
	}
	if (allComponents != NULL) {
		delete[] allComponents;
	}
	if (indexPositions != NULL) {
		delete[] indexPositions;
	}
	GLCall(glDeleteBuffers(1, &shape_vbo));
	GLCall(glDeleteBuffers(1, &shape_ibo));
	GLCall(glDeleteBuffers(1, &vbo2));
	GLCall(glDeleteVertexArrays(1, &shape_vao));
	//GLCall(glDeleteIndexArrays)
}

unsigned int RenderableShape::ReturnVAO()
{
	return shape_vao;
}

unsigned int RenderableShape::GetVertexSize()
{
	return numVertices;
}

unsigned int RenderableShape::GetTier()
{
	return tier;
}


