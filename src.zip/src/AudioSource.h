#pragma once
#include "AL\alut.h"
#include "AL\al.h"
#include "AL\alc.h"
#include <string>
class AudioSource {
private:
	ALuint source, buffer;
	ALenum state;

public:
	AudioSource(std::string filePath);
	~AudioSource();
	void PlayAudio();
	void PauseAudio();
	void SetPosition(float x, float y, float z);
	void SetPitch(float pitch);
	void SetGain(float gains);
	void SetLooping(bool loop);
	void SetFallOffFactor(float falloff);
	bool GetIsPlaying();
	void SetVelocity(float vx, float vy, float vz);
	void StopAudio();
	void SetMinDistance(float minDistance);
	void SetMaxDistance(float maxDistance);
	void SetMinGain(float normalizedMin);
	void SetMaxGain(float normalizedMax);
	void ForceMaximumMaxDistance();
	ALenum GetState();
};