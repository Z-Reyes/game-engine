#pragma once
#include <string>
#include "OpenGL_Assertions.h"
#include "Texture.h"
#include <string>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <assimp\Importer.hpp>
#include <assimp\scene.h>
#include <assimp\postprocess.h>
/*
The RenderableShape class is a container for a vao with the vertices, texture coordinates, normal vectors,
and indices that define a shape. Shapes are read in from .zShape files, and are built on construction.
RenderableObjects refer to a desired shape via a string ID, which is requested from the MemoryManager.
*/
class RenderableShape {
public:
	/*
	Builds a RenderableShape based off of the zShape file specified by filepath.
	*/
	RenderableShape(std::string filepath, bool useAssimp);
	RenderableShape(std::string fileloc, const aiScene* scene, aiMesh * mesh, std::vector<std::string> *loadT, std::vector<std::string> *texN);
	RenderableShape();
	RenderableShape(float * forceAllComponents, unsigned int inSize, unsigned int * inIndex,  unsigned int inNumVertices, unsigned int * jointIds, unsigned int jointIdSize);
	/*
	Destroys associated structures and frees up glBinders.
	*/
	~RenderableShape();
	/*
	Returns the vao id associated with the current shape. Used by the RenderManager.
	*/
	unsigned int ReturnVAO();
	/*
	Returns the number of triangles to draw. Used by the RenderManager.
	*/
	unsigned int GetVertexSize();
	/*
	Returns the maximum rendering tier accessible by this object. Used in calculating how advanced the rendering
	pipeline is for this particular shape.
	*/
	unsigned int GetTier();

	//void AssimpPackRenderableShape();
	void ImportTextureIntoMemory(aiMaterial *mat, aiTextureType type, std::string typeName, std::vector<std::string>* loadedTextures, std::vector<std::string>* textureNames);

	std::string GetShapeTexture();
private:
	/*
	tier is the maximum tier value for rendering. numVertices is the number of triangles to be drawn.
	In the case of drawing via index buffer objects, numVertices is the number of indices.
	*/
	unsigned int tier, numVertices;
	/*
	vao, vbo, and ibo identifiers for opengl.
	*/
	unsigned int shape_vao, shape_vbo, shape_ibo, vbo2;
	/*
	Container for raw vertex positions
	*/
	float* positions;
	/*
	Container for raw texture coordinates.
	*/
	float* tex_positions;
	/*
	Container for raw normal vectors.
	*/
	float* normals;
	/*
	Container for connected position, texture, and normal vectors. Used for vbo specification.
	*/
	float* allComponents;
	/*
	Container for index values for rendering.
	*/
	unsigned int* indexPositions;
	/*
	Reads a model in from the zShape file format. Not super safe at this point.
	*/
	void ReadZshapeFile(std::string filepath);
	/*
	Imports a model using assimp.
	*/
	//void LoadViaAssimp(aiMesh * mesh);
	/*
	Just used for storing the filepath
	*/
	std::string directory;
	/*
	Used for model loading textures
	*/
	std::string mesh_texture;
};