#pragma once
#include "OpenGL_Assertions.h"

#include "Renderable_Object.h"
#include "Shader.h"
#include "Camera.h"
#include "Memory_Manager.h"
#include "Light.h"
#include <sstream>
#include <string>
#include <unordered_map>
/*
The RenderManager class is in charge of rendering the Renderable Objects in its render queue.
As of 3/26/19, it only has an opaque render queue.
*/
class RenderManager {
public:
	
	/*
	Creates a static RenderManager singleton. Prevents the creation of another one.
	*/
	static RenderManager* get();
	/*
	Loads the default shaders into the RenderManager. Meant to be called solely by the Startup method.
	*/
	void LoadDefaultShaders();
	/*
	Draws every item in the opaque render queue. Should be called for every OnRender call.
	*/
	void DrawOpaqueRenderQueue();
	/*
	Starts up the RenderManager, loading the default shaders and initializing the manager.
	*/
	void Startup();
	/*
	Empties all components to close down the RenderManager.
	*/
	void Shutdown();
	/*
	Adds a Shader to the list of available shaders for the RenderManager. filepath is the filepath to the .shader file,
	and the shaderID is the identifier used by that shader.
	*/
	void AddShader(std::string filepath, std::string shaderID);
	/*
	Request a shader of identifier identifier from the RenderManager. Returns a nullptr on failure.
	*/
	Shader* RequestShader(std::string identifier);
	/*
	Adds a new RenderableObject to the opaque render queue.
	*/
	void AppendOpaqueRenderQueue(RendereableObject* renderItem);
	/*
	A deprecated method. Do not use anymore.
	*/
	void SetCameraMatrix(Camera cam);
	/*
	Sets the projection matrix to be used by this RenderManager. 
	*/
	void SetProjectionMatrix(Zat4 proj);
	/*
	Appends a light object to the Render Queue
	*/
	void AppendLightQueue(light * insert);
	/*
	Removes a light object with identifier matching id.
	*/
	void DeleteLightWithIdentifier(unsigned int id);
	/*
	A crappy method for rendering an animated shape with tier 1 level rendering.
	*/
	void RenderAnimatedObject(RenderableShape * animatedShape, Zat4* allJointTransforms, int numJoints);
	void SetSkyFrame(RendereableObject * desiredFrame);
	void DrawSkyFrame();

private:
	RenderManager();
	/*
	Destroys the RenderManager.
	*/
	~RenderManager();
	unsigned int screenHeight, screenWidth;
	std::unordered_map<std::string, Shader*> shaderList;
	std::vector<RendereableObject*> opaqueRenderQueue;
	std::vector<light*> lightQueue;
	const unsigned int maxDirectional = 1;
	const unsigned int maxPositional = 4;
	unsigned int numDirectional, numPositional;
	Zat4 projectionMatrix;
	Camera renderCam;
	Zat4 cameraMatrix;
	bool isStarted = false;
	static RenderManager* singletonRM;
	RendereableObject* skyFrame;


};
/*
Basically another way to call RenderManager::get();
*/
RenderManager* CreateStaticRM();
