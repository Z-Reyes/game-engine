#include "Z_Math.h"



static Position_Bag AddPosition_Bags(Position_Bag* &a, Position_Bag* &b) {
	return Position_Bag(a->location[0] + b->location[0], 
						a->location[1] + b->location[1], 
						a->location[2] + b->location[2], 
						a->location[3] + b->location[3]);
}

static Position_Bag SubPosition_Bags(Position_Bag* &a, Position_Bag* &b) {
	return Position_Bag(a->location[0] - b->location[0],
						a->location[1] - b->location[1],
						a->location[2] - b->location[2],
						a->location[3] - b->location[3]);
}
static Position_Bag ScalarMultiplyPB(float m, Position_Bag* &a) {
	return Position_Bag(m * a->location[0], m * a->location[1], m * a->location[2], m * a->location[3]);
}

static Position_Bag ReversePB(Position_Bag* &a) {
	return Position_Bag(-a->location[0], -a->location[1], -a->location[2], a->location[3]);
}

Zec3 operator-(Zec3 &a)
{
	Position_Bag* d = a.GetDirection();
	Position_Bag reversedValues = ReversePB(d);
	return Zec3(reversedValues.location[0], reversedValues.location[1], reversedValues.location[2]);
}

Zos operator-(Zos & a)
{
	Position_Bag* d = a.GetPosition();
	Position_Bag reversedValues = ReversePB(d);
	return Zos(reversedValues.location[0], reversedValues.location[1], reversedValues.location[2]);
}

Zec3 PositionPositionSubtraction(Zos &source, Zos &destination)
{
	Position_Bag* positions[2] = { source.GetPosition(), destination.GetPosition() };
	Position_Bag newPosition = SubPosition_Bags(positions[0], positions[1]);
	return Zec3(newPosition.location[0], newPosition.location[1], newPosition.location[2]);
}

Zec3 operator-(Zos &source, Zos &destination) {
	return PositionPositionSubtraction(source, destination);
}

Zos PositionDirectionAddition(Zos &point, Zec3 &direction)
{
	Position_Bag* directions[2] = { point.GetPosition(), direction.GetDirection() };
	Position_Bag newDirection = AddPosition_Bags(directions[0], directions[1]);
	return Zos(newDirection.location[0], 
			   newDirection.location[1],
			   newDirection.location[2]);
}
Zos operator+(Zos &source, Zec3 &direction) {
	return PositionDirectionAddition(source, direction);
}

Zec3 DirectionDirectionSubtraction(Zec3 &d1, Zec3 &d2)
{
	Position_Bag* directions[2] = { d1.GetDirection(), d2.GetDirection() };
	Position_Bag newDirection = SubPosition_Bags(directions[0], directions[1]);
	return Zec3(newDirection.location[0],
				newDirection.location[1],
				newDirection.location[2]);
}

Zec3 operator-(Zec3 &d1, Zec3 &d2) {
	return DirectionDirectionSubtraction(d1, d2);
}

Zec3 DirectionDirectionAddition(Zec3 &d1, Zec3 &d2)
{
	Position_Bag* directions[2] = { d1.GetDirection(), d2.GetDirection() };
	Position_Bag newDirection = AddPosition_Bags(directions[0], directions[1]);
	return Zec3(newDirection.location[0],
				newDirection.location[1],
				newDirection.location[2]);
}
Zec3 operator+(Zec3 &d1, Zec3 &d2) {
	return DirectionDirectionAddition(d1, d2);
}

Zec3 ScalarDirectionMultiplication(float multiplier, Zec3 &source) {
	Position_Bag* source_values = source.GetDirection();
	Position_Bag newDirection = ScalarMultiplyPB(multiplier, source_values);
	return Zec3(newDirection.location[0],
				newDirection.location[1],
				newDirection.location[2]);
}
Zec3 operator*(float multiplier, Zec3 &source) {
	return ScalarDirectionMultiplication(multiplier, source);
}

Zos ScalarPositionMultiplication(float multiplier, Zos &source) {
	Position_Bag* source_values = source.GetPosition();
	Position_Bag newPosition = ScalarMultiplyPB(multiplier, source_values);
	return Zos(newPosition.location[0], newPosition.location[1], newPosition.location[2]);
}
Zos operator*(float multiplier, Zos &source) {
	return ScalarPositionMultiplication(multiplier, source);
}

//Dot Product.
float operator*(Zec3 &a, Zec3 &b) {
	Position_Bag* directions[2] = { a.GetDirection(), b.GetDirection() };

	return directions[0]->location[0] * directions[1]->location[0]
		+ directions[0]->location[1] * directions[1]->location[1]
		+ directions[0]->location[2] * directions[1]->location[2];
}

Zec3 Cross(Zec3 &a, Zec3 &b)
{
	Position_Bag* directions[2] = { a.GetDirection(), b.GetDirection() };
	float xMult1 = directions[0]->location[1] * directions[1]->location[2];
	float xMult2 = directions[0]->location[2] * directions[1]->location[1];

	float yMult1 = directions[0]->location[2] * directions[1]->location[0];
	float yMult2 = directions[0]->location[0] * directions[1]->location[2];

	float zMult1 = directions[0]->location[0] * directions[1]->location[1];
	float zMult2 = directions[0]->location[1] * directions[1]->location[0];

	
	return Zec3((xMult1 - xMult2), (yMult1 - yMult2), (zMult1 - zMult2));
}

Zec3 Normalize(Zec3 &norm)
{
	Position_Bag* vectors = norm.GetDirection();
	float mag = Mag(norm);
	return Zec3(vectors->location[0]/mag, vectors->location[1] / mag, vectors->location[2] / mag );
}

float Projection(Zec3 &unto, Zec3 &onto)
{
	Normalize(unto); //guarantees that unto will be normalized.
	return (onto * unto);
}

Zec3 Lerp(Zec3 &a, Zec3 &b, float beta)
{
	//Clamp beta values so that it is always within 0.0f and 1.0f;
	if (beta < 0.0f) {
		beta = 0;
	}
	else if (beta > 1.0f) {
		beta = 1.0f;
	}

	return ((1.0f - beta) * a) + beta * b;
}

float Mag(Zec3 &source) {
	return (sqrt(source * source));
}

//Taken from class lecture slides.
__m128 AddWithIntrinsics(const __m128 a, const __m128 b)
{
	return _mm_add_ps(a, b);
}

Zat4 AddMatrixMatrix(Zat4 &ad1, Zat4 &ad2) {
	float * v = ad2.GetMatrix();
	float * v2 = ad1.GetMatrix();
	Zat4 re;
	for (int i = 0; i < 15; i++) {
		re.AddAtLocation(v[i] + v2[i], i);
		//re.AddAtLocation(v2[i], i);
	}
	return re;
}

Zat4 operator+(Zat4 &ad1, Zat4 &ad2) {
	return AddMatrixMatrix(ad1, ad2);
}

//Needs to be changed so not so reliant on hard-coded values?
Zat4 MultiplyMatrixMatrix(Zat4 &ad1, Zat4 &ad2) {
	float * v = ad1.GetMatrix();
	float * v2 = ad2.GetMatrix();
	Zat4 re;
	re.AddAtLocation(-1.0f, 15);

	for (int column = 0; column < 4; column++) {

		for (int row = 0; row < 4; row++) {
			int mataStart = row * 4;
			int matbStart = column;
			re.AddAtLocation((v[mataStart]*v2[matbStart])+
							 (v[mataStart + 1] * v2[matbStart + 4])+
							 (v[mataStart + 2] * v2[matbStart + 8])+
							 (v[mataStart + 3] * v2[matbStart + 12]), (mataStart) + column);
		}
	}
	return re;
}


Position_Bag MultiplyMatrixBag(Zat4 &b, Position_Bag *store) {
	float * mat = b.GetMatrix();
	float xValue[4];
	xValue[0] = store->location[0] * mat[0] + store->location[1] * mat[4] + store->location[2] * mat[8] + store->location[3] * mat[12];
	xValue[1] = store->location[0] * mat[1] + store->location[1] * mat[5] + store->location[2] * mat[9] + store->location[3] * mat[13];
	xValue[2] = store->location[0] * mat[2] + store->location[1] * mat[6] + store->location[2] * mat[10] + store->location[3] * mat[14];
	xValue[3] = store->location[0] * mat[3] + store->location[1] * mat[7] + store->location[2] * mat[11] + store->location[3] * mat[15];
	//std::cout << xValue[3] << "jajaja" << std::endl;
	return Position_Bag(xValue[0], xValue[1], xValue[2], xValue[3]);
	
}
Zec3 MultiplyDirectionMatrix(Zec3 &a, Zat4 &b)
{
	Position_Bag multiplyValues = MultiplyMatrixBag(b, a.GetDirection());
	//std::cout << xValue[3] << "jajaja" << std::endl;
	return Zec3(multiplyValues.location[0], multiplyValues.location[1], multiplyValues.location[2], multiplyValues.location[3]);
}
Zec3 operator* (Zat4 &b, Zec3 &a) {
	return MultiplyDirectionMatrix(a, b);
}

Zos MultiplyPositionMatrix(Zos &a, Zat4 &b) {
	Position_Bag multiplyValues = MultiplyMatrixBag(b, a.GetPosition());
	//std::cout << xValue[3] << "jajaja" << std::endl;
	return Zos(multiplyValues.location[0], multiplyValues.location[1], multiplyValues.location[2]);
}
Zos operator* (Zat4 &b, Zos &a) {
	return MultiplyPositionMatrix(a, b);
}

Zec3 QuickMultiplyDirectionMatrix(Zec3 &a, Zat4 &b)
{
	Position_Bag* vec = a.GetDirection();
	Sse_get result;
	const __m128 scalars[4] = { _mm_set1_ps(vec->location[0]), 
								_mm_set1_ps(vec->location[1]), 
								_mm_set1_ps(vec->location[2]), 
								_mm_set1_ps(vec->location[3]) };
	__m128 vArr[4];
	float *matts = b.GetMatrix();
	vArr[0] = _mm_set_ps(matts[0], matts[1], matts[2], matts[3]);
	vArr[0] = _mm_mul_ps(scalars[0], vArr[0]);

	vArr[1] = _mm_set_ps(matts[4], matts[5], matts[6], matts[7]);
	vArr[1] = _mm_mul_ps(scalars[1], vArr[1]);

	vArr[2] = _mm_set_ps(matts[8], matts[9], matts[10], matts[11]);
	vArr[2] = _mm_mul_ps(scalars[2], vArr[2]);

	vArr[3] = _mm_set_ps(matts[12], matts[13], matts[14], matts[15]);
	vArr[3] = _mm_mul_ps(scalars[3], vArr[3]);

	result.reg = _mm_add_ps(vArr[0], vArr[1]);
	result.reg = _mm_add_ps(result.reg, vArr[2]);
	result.reg = _mm_add_ps(result.reg, vArr[3]);
	
	
	//Now we need to return the values.
	return Zec3(result.re[3], result.re[2], result.re[1], result.re[0]);
}


Zat4 QuickMultiplyMatrixMatrix(Zat4 &a, Zat4 &b) {
	float *mattsa = a.GetMatrix();
	float *mattsb = b.GetMatrix();
	Zat4 toBeReturned;
	float *toBeReturnedValues = toBeReturned.GetMatrix();
	__m128 aValues[4];
	__m128 matrixRows[4] = { _mm_set_ps(mattsa[0], mattsa[1], mattsa[2], mattsa[3]),
							 _mm_set_ps(mattsa[4], mattsa[5], mattsa[6], mattsa[7]),
							 _mm_set_ps(mattsa[8], mattsa[9], mattsa[10], mattsa[11]),
							 _mm_set_ps(mattsa[12], mattsa[13], mattsa[14], mattsa[15]) };
	__m128 vArr[4];
	Sse_get rowResult;
	for (int i = 0; i < 4; i++) {
		int iteration = i * 4;
		//Load the values of a into aValues.
		//This may be inefficient
		aValues[0] = _mm_set1_ps(mattsb[iteration]);
		aValues[1] = _mm_set1_ps(mattsb[(iteration) + 1]);
		aValues[2] = _mm_set1_ps(mattsb[(iteration) + 2]);
		aValues[3] = _mm_set1_ps(mattsb[(iteration) + 3]);

		//Yeah now we need to store matrix columns
		vArr[0] = _mm_mul_ps(aValues[0], matrixRows[0]);

		vArr[1] = _mm_mul_ps(aValues[1], matrixRows[1]);

		vArr[2] = _mm_mul_ps(aValues[2], matrixRows[2]);

		vArr[3] = _mm_mul_ps(aValues[3], matrixRows[3]);

		rowResult.reg = _mm_add_ps(vArr[0], vArr[1]);
		rowResult.reg = _mm_add_ps(rowResult.reg, vArr[2]);
		rowResult.reg = _mm_add_ps(rowResult.reg, vArr[3]);
		
		
		toBeReturnedValues[iteration + 3] = rowResult.re[0];
		toBeReturnedValues[iteration + 2] = rowResult.re[1];
		toBeReturnedValues[iteration + 1] = rowResult.re[2];
		toBeReturnedValues[iteration] = rowResult.re[3];
	}

	return toBeReturned;

}

Zat4 operator*(Zat4 &a, Zat4 &b) {
	return QuickMultiplyMatrixMatrix(a, b);
}

Zat4 Translate(float x, float y, float z)
{
	Zat4 translateM(1.0f);
	translateM.AddAtLocation(x, 12);
	translateM.AddAtLocation(y, 13);
	translateM.AddAtLocation(z, 14);
	return translateM;
}

Zat4 Translate(Zos translate) {
	Position_Bag* val = translate.GetPosition();
	Zat4 translateM(1.0f);
	translateM.AddAtLocation(val->location[0], 12);
	translateM.AddAtLocation(val->location[1], 13);
	translateM.AddAtLocation(val->location[2], 14);
	return translateM;
}

Zat4 Translate(Zec3 translate) { //Hopefully this doesn't break anything.
	Position_Bag* val = translate.GetDirection();
	Zat4 translateM(1.0f);
	translateM.AddAtLocation(val->location[0], 12);
	translateM.AddAtLocation(val->location[1], 13);
	translateM.AddAtLocation(val->location[2], 14);
	return translateM;
}
//Transposes the given matrix a
Zat4 Transpose(Zat4 & a)
{
	float *originalMat = a.GetMatrix();
	Zat4 returnedMat(originalMat[0], originalMat[5], originalMat[10]);
	returnedMat.AddAtLocation(originalMat[4], 1);
	returnedMat.AddAtLocation(originalMat[1], 4);

	returnedMat.AddAtLocation(originalMat[8], 2);
	returnedMat.AddAtLocation(originalMat[2], 8);

	returnedMat.AddAtLocation(originalMat[12], 3);
	returnedMat.AddAtLocation(originalMat[3], 12);

	returnedMat.AddAtLocation(originalMat[9], 6);
	returnedMat.AddAtLocation(originalMat[6], 9);

	returnedMat.AddAtLocation(originalMat[13], 7);
	returnedMat.AddAtLocation(originalMat[7], 13);

	returnedMat.AddAtLocation(originalMat[14], 11);
	returnedMat.AddAtLocation(originalMat[11], 14);
	return returnedMat;
}

Zat4  operator$(Zat4 &a) {
	return Transpose(a);
}

//input is assumed to be two unit quaternions
//Pulled from https://www.mathworks.com/help/aerotbx/ug/quatmultiply.html
Quaternion MultiplyQuaternions(Quaternion & a, Quaternion & b)
{
	Position_Bag * quads[2] = { a.getQuad(), b.getQuad() };
	float w = (quads[1]->location[3] * quads[0]->location[3])
			- (quads[1]->location[0] * quads[0]->location[0])
			- (quads[1]->location[1] * quads[0]->location[1])
			- (quads[1]->location[2] * quads[0]->location[2]);

	float x = (quads[1]->location[3] * quads[0]->location[0])
			+ (quads[1]->location[0] * quads[0]->location[3])
			- (quads[1]->location[1] * quads[0]->location[2])
			+ (quads[1]->location[2] * quads[0]->location[1]);
	
	float y = (quads[1]->location[3] * quads[0]->location[1])
			+ (quads[1]->location[0] * quads[0]->location[2])
			+ (quads[1]->location[1] * quads[0]->location[3])
			- (quads[1]->location[2] * quads[0]->location[0]);

	float z = (quads[1]->location[3] * quads[0]->location[2])
			 -(quads[1]->location[0] * quads[0]->location[1])
			+ (quads[1]->location[1] * quads[0]->location[0])
			+ (quads[1]->location[2] * quads[0]->location[3]);
			// std::cout << quads[1]->location[0] << quads[0]->location[1] << std::endl;
	return Quaternion(x,y,z,w);
}

Quaternion QuaternionInverse(Quaternion &a) {
	Position_Bag* data = a.getQuad();
	return Quaternion(-data->location[0], -data->location[1], -data->location[2], data->location[3]);
}

Zos ConvertZecToZos(Zec3 & a)
{
	Position_Bag* temp = a.GetDirection();
	return Zos(temp->location[0], temp->location[1], temp->location[2]);
}

Zec3 ConvertZosToZec3(Zos & a)
{
	Position_Bag* temp = a.GetPosition();
	return Zec3(temp->location[0], temp->location[1], temp->location[2]);
}

Zat4 RotateZAxis(float radians)
{
	while (radians > 6.28f) {
		radians -= 6.28f;
	}
	Zat4 zRotationMat(0.0f, 0.0f, 1.0f);
	double cosineAngle = cos(radians);
	double sineAngle = sin(radians);
	zRotationMat.AddAtLocation(cosineAngle, 0);
	zRotationMat.AddAtLocation(cosineAngle, 5);
	zRotationMat.AddAtLocation(-sineAngle, 1);
	zRotationMat.AddAtLocation(sineAngle, 4);

	return zRotationMat;
}

Zat4 RotateXAxis(float radians)
{
	while (radians > 6.28f) {
		radians -= 6.28f;
	}
	Zat4 xRotationMat(1.0f, 0.0f, 0.0f);
	double cosineAngle = cos(radians);
	double sineAngle = sin(radians);
	xRotationMat.AddAtLocation(cosineAngle, 5);
	xRotationMat.AddAtLocation(cosineAngle, 10);
	xRotationMat.AddAtLocation(-sineAngle, 6);
	xRotationMat.AddAtLocation(sineAngle, 9);

	return xRotationMat;
}

Zat4 RotateYAxis(float radians)
{
	while (radians > 6.28f) {
		radians -= 6.28f;
	}
	Zat4 yRotationMat(0.0f, 1.0f, 0.0f);
	double cosineAngle = cos(radians);
	double sineAngle = sin(radians);

	yRotationMat.AddAtLocation(cosineAngle, 0);
	yRotationMat.AddAtLocation(cosineAngle, 10);
	yRotationMat.AddAtLocation(sineAngle, 2);
	yRotationMat.AddAtLocation(-sineAngle, 8);

	return yRotationMat;
}
float RandomNum(int lowerBound, int higherBound)
{
	return float((rand() % higherBound) + lowerBound);
}
//Assistance from http://www.cplusplus.com/reference/cstdlib/rand/
void InitializeRNGSeed()
{
	srand(time(NULL));
}

Quaternion operator*(Quaternion & a, Quaternion & b)
{
	return MultiplyQuaternions(a, b);
}

Zec3 RotateWQuaternion(Zec3 &input, Zec3 &axis, float radians)
{
	//Make sure radians is capped at maximum value.
	while (radians > 6.28f) {
		radians -= 6.28f;
	}
	//Will also need to normalize input and axis.
	float mag = Mag(input);
	Zec3 nInput = Normalize(input);
	Zec3 nAxis = Normalize(axis);
	double vectorHalfAngle = sin(radians / 2);
	double realHalfAngle = cos(radians / 2);
	Position_Bag* elements = nInput.GetDirection();
	Position_Bag* axisElements = (vectorHalfAngle * nAxis).GetDirection();

	Quaternion rotationQuaternion(axisElements->location[0], axisElements->location[1], axisElements->location[2], realHalfAngle );
	Quaternion rotationQuaternionInverse = QuaternionInverse(rotationQuaternion);
	Position_Bag* newVectorValues = ((rotationQuaternion * Quaternion(elements->location[0], elements->location[1], elements->location[2], elements->location[3])) * rotationQuaternionInverse).getQuad();
	Zec3 finalVector(newVectorValues->location[0], newVectorValues->location[1], newVectorValues->location[2]);
	return mag * finalVector;
}

Zec3 RotateWQuaternion(Zec3 &input, float x, float y, float z, float radians)
{
	Zec3 temp(x, y, z);

	return RotateWQuaternion(input, temp, radians);
}

Zat4 Rotate(Zec3 axis_of_rotation, float radians) {
	//Make sure radians is capped at maximum value.
	while (radians > 6.28f) {
		radians -= 6.28f;
	}
	//Will also need to normalize input and axis.
	//float mag = Mag(input);
	//Zec3 nInput = Normalize(input);
	Zec3 nAxis = Normalize(axis_of_rotation);
	double vectorHalfAngle = sin(radians / 2);
	double realHalfAngle = cos(radians / 2);
	Position_Bag* axisElements = (vectorHalfAngle * nAxis).GetDirection();

	Quaternion rotationQuaternion(axisElements->location[0], axisElements->location[1], axisElements->location[2], realHalfAngle);
	return QuaternionToRM(rotationQuaternion);
}

Zat4 QuaternionToRM(Quaternion &in) {
	Position_Bag* quadPositions = in.getQuad();
	float x = quadPositions->location[0];
	float y = quadPositions->location[1];
	float z = quadPositions->location[2];
	float w = quadPositions->location[3];
	Zat4 qRM;
	qRM.AddAtLocation(1 - (2 * (y * y)) - (2 * (z * z)), 0);
	qRM.AddAtLocation((2 * x * y) - (2 * z * w), 1);
	qRM.AddAtLocation((2 * x * z) + (2 * y * w), 2);

	qRM.AddAtLocation((2 * x * y) + (2 * z * w),4);
	qRM.AddAtLocation(1 - (2 * x * x) - (2 * z * z), 5);
	qRM.AddAtLocation((2 * y * z) - (2 * x * w), 6);

	qRM.AddAtLocation((2 * x * z) - (2 * y * w),8);
	qRM.AddAtLocation((2 * y * z) + (2 * x * w), 9);
	qRM.AddAtLocation(1 - (2 * x * x) - (2 * y * y), 10);
	return qRM;
}

Quaternion AddQuaternionQuaternion(Quaternion &a, Quaternion &b) {
	Position_Bag* quads[2] = { a.getQuad(), b.getQuad() };
	Position_Bag newQuad = AddPosition_Bags(quads[0], quads[1]);
	return Quaternion(newQuad.location[0], newQuad.location[1], newQuad.location[2], newQuad.location[3]);
}

Quaternion operator+(Quaternion &a, Quaternion &b) {
	return AddQuaternionQuaternion(a, b);
}

Quaternion MultiplyScalarQuaternion(float multiplier, Quaternion&a) {
	Position_Bag *quad = a.getQuad();
	Position_Bag newQuad = ScalarMultiplyPB(multiplier, quad);
	return Quaternion(newQuad.location[0], newQuad.location[1], newQuad.location[2], newQuad.location[3]);
}

Quaternion operator*(float multiplier, Quaternion &a) {
	return MultiplyScalarQuaternion(multiplier, a);
}

float Mag(Quaternion &a) {
	Position_Bag *quad = a.getQuad();
	float xSquared = pow(quad->location[0], 2);
	float ySquared = pow(quad->location[1], 2);
	float zSquared = pow(quad->location[2], 2);
	float wSquared = pow(quad->location[3], 2);
	return sqrt(xSquared + ySquared + zSquared + wSquared);
}

Quaternion Lerp(Quaternion &a, Quaternion &b, float beta) {
	
	if (beta < 0.0f) {
		beta = 0;
	}
	else if (beta > 1.0f) {
		beta = 1.0f;
	}
	Quaternion combined = (((1.0f - beta)*a) + (beta * b));

	return (1.0f / Mag(combined)) * combined;
}

Zat4 IdentityMat()
{
	return Zat4(1.0f);
}

Zat4 Perspective(float fov, float nearClip, float farClip)
{
	Zat4 returnedMatrix;

	float s = 1 / tan(fov * 0.5f * 3.1415 / 180);
	float clip1 = -(farClip / (farClip-nearClip));
	float clip2 = clip1 * nearClip;
	returnedMatrix.AddAtLocation(-1.0f, 15);

	returnedMatrix.AddAtLocation(s, 0);
	returnedMatrix.AddAtLocation(s, 5);
	returnedMatrix.AddAtLocation(clip1, 10);
	returnedMatrix.AddAtLocation(clip2, 14);
	returnedMatrix.AddAtLocation(-1.0f, 11);
	std::cout << returnedMatrix.PrintMatrixValues() << std::endl;
	return returnedMatrix;

}
/*
Same thing as Perspective except specialized to OpenGL.
*/
Zat4 OpenGlPerspective(float fov, float nearClip, float farClip, float aspectRatio)
{
	Zat4 openglMatrix;
	//float top = tan(fov / 2) * nearClip;
	//float bot = -top;

	//float right = top * aspectRatio;
	//float left = -right;
	openglMatrix.AddAtLocation(-1.0f, 15);

	//openglMatrix.AddAtLocation((2.0f * nearClip)/(right - left), 0);
	//openglMatrix.AddAtLocation((2.0f * nearClip)/(top - bot), 5);
	float top = tan(fov / 2) * nearClip;
	float right = top * aspectRatio;
	float bottom = -top;
	float left = bottom * aspectRatio;
	
	//openglMatrix.AddAtLocation((right + left)/(right - left), 8);
	//openglMatrix.AddAtLocation((top + bot)/(top - bot), 9);
	openglMatrix.AddAtLocation((2 * nearClip)/ (right - left), 0);
	openglMatrix.AddAtLocation((2 * nearClip) / (top - bottom), 5);
	openglMatrix.AddAtLocation((right + left) / (right - left), 8);
	openglMatrix.AddAtLocation((top + bottom) / (top - bottom), 9);
	openglMatrix.AddAtLocation(-(farClip + nearClip)/(farClip - nearClip), 10);
	openglMatrix.AddAtLocation(-1.0f, 11);
	//openglMatrix.AddAtLocation(-(2.0f * farClip * nearClip)/(farClip - nearClip), 14);
	openglMatrix.AddAtLocation(-(2.0f * farClip * nearClip) / (farClip - nearClip), 14);
	return openglMatrix;

}


