#pragma once
#include "Z_Math.h"
#include "Material.h"
#include "PhysicsHeaders.h"
//#include "PhysicsManager.h"
/*
The RenderableObject class is a virtual class that specifies an object that will be given to the Render_Manager to be drawn.
To create a real RenderableObject, create a subclass of RenderableObject and specify the OnUpdate method.
*/
class RendereableObject {
public:
	/*
	Constructor and destructor don't do anything.
	*/
	RendereableObject() {}
	~RendereableObject() {}
	/*
	Returns whether this object is renderable. If true, it means the object can be drawn. If not, it means
	the object is missing some specifications.
	*/
	bool isRenderable();
	/*
	Sets whether translation should precede rotation in the model to world transition
	If true, translation will occur before model rotation. If false, rotation happens before translation.
	*/
	void Translation_Rotation_Order_set(bool tr);
	/*
	Sets whether parent translation should precde frotation in the parent to model transition.
	If true, translation will occur before model rotation. If false, rotation happens before translation.
	*/
	void Set_Parent_T_Rotation_Order(bool pTr);
	/*
	Sets whether parent translation should be used in the parent to model transition.
	If true, parent translation will be used. If false, parent translation will not be used.
	*/
	void Use_Parent_Translation(bool usePT);
	/*
	Sets whether parent rotation should be used in the parent to model transition.
	If true, parent rotation will be used. If false, parent rotation will not be used.
	*/
	void Use_Parent_Rotation(bool usePR);
	/*
	Sets whether model translation and rotation should occur before parent translation and rotation.
	If true, model will update relative to itself before applying parent transitions. If false, the parent
	transitions will occur first.
	*/
	void Set_Self_Changes_First(bool sf);
	/*
	Doesn't do much at this point. Will be filled out later.
	*/
	int IsRenderable();
	/*
	Sets the desired rendering tier of this object. Used in the Rendering pipeline to determine how advanced the
	rendering will be.
	*/
	void SetDesiredTier(unsigned int dt);
	/*
	Sets the shader ID to be used by this object. sID is the identifier that will be used in the RenderManager.
	*/
	void SetShaderID(std::string sID);
	/*
	Sets the shape ID to be used by this object. shID is the identifier that will be used in MemoryManager (by RenderManager).
	*/
	void SetShapeID(std::string shID);
	/*
	Sets the texture ID to be used by this object. tID is the identifier that will be used in MemoryManager (by RenderManager).
	*/
	void SetTexID(std::string tID);
	/*
	Returns the desired rendering tier of this object.
	*/
	unsigned int GetDesiredTier();
	/*
	Returns the shader ID used by this object.
	*/
	std::string GetShaderID();
	/*
	Returns the shape ID used by this object.
	*/
	std::string GetShapeID();
	/*
	Returns the texture ID used by this object.
	*/
	std::string GetTexID();
	/*
	Sets the x, y, and z position coordinates of this RenderableObject.
	*/
	void SetPosition(float x, float y, float z);
	/*
	Sets the x, y, and z scale values of this RenderableObject.
	*/
	void SetScale(float xs, float ys, float zs);
	/*
	Sets the rotation of this RenderableObject around axis by radians radians.
	*/
	void SetRotation(Zec3 axis, float radians);
	/*
	Returns the Model to World Matrix of this RenderableObject.
	*/
	Zat4 ProduceModelMatrix();
	/*
	virtual method to be defined in subclasses.
	*/
	Position_Bag* GetPosition();
	float GetScaleX();
	float GetScaleY();
	float GetScaleZ();
	virtual void OnUpdate() = 0;

	void SetUseMyTexture(bool t);
	bool GetUseMyTexture();
	/*
	Returns the material for this renderable object.
	*/
	material *GetMyMaterial();
	void SetMyMaterial(material mat);

	/*
	Physics-specific Commands and variables.
	*/
	bool usePhysics;
	float friction, restitution, mass;
	Position_Bag initialForce;
	void UpdateRigidBodyValues();
	btRigidBody* myBody;
	//btCollisionObject * myObj;
	void ApplyPhysicsChanges();
	//Quaternion myRotation;
	void ForceObjectPositionOnPhysics();
private:
	//RendereableObject * child;
	material mMaterial;
	bool trans_first, parent_trans_first, use_parent_trans, use_parent_rotation, self_first, useMyTexture;
	std::string shader_id, shape_id, texture_id;
	unsigned int thisID, desiredTier;
	Zos position;
	float scaleX, scaleY, scaleZ;
	Zat4 curr_rotation;

	void PhysicsRotationCalculate();
	

};