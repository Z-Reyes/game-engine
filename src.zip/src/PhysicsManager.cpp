#include "PhysicsManager.h"

PhysicsManager* PhysicsManager::singletonPM = nullptr;
void PhysicsManager::StartUp()
{

	collisionConfiguration = new btDefaultCollisionConfiguration();

	dispatcher = new btCollisionDispatcher(collisionConfiguration);
	overlappingPairCache = new btDbvtBroadphase();

	solver = new btSequentialImpulseConstraintSolver();
	dynamicsWorld = new btDiscreteDynamicsWorld(dispatcher, overlappingPairCache, solver, collisionConfiguration);
	dynamicsWorld->setGravity(btVector3(0, -10, 0));

	btCollisionShape* colShape;
	colShape = new btStaticPlaneShape(btVector3(0,1,0),-100);

	collisionShapes.push_back(colShape);
	btTransform startTransform;
	startTransform.setIdentity();

	btVector3 localInertia(0, 0, 0);

	btDefaultMotionState* myMotionState = new btDefaultMotionState(startTransform); // might need to do something about then.
	btRigidBody::btRigidBodyConstructionInfo rbInfo(0.0, myMotionState, colShape, localInertia);
	btRigidBody* body = new btRigidBody(rbInfo);

	body->setRestitution(1.0);
	dynamicsWorld->addRigidBody(body);
	isStarted = true;
}

void PhysicsManager::Shutdown()
{
	/*
	Code taken from a Hello World example in the Bullet 2.88 master files.
	*/

	for (int i = dynamicsWorld->getNumCollisionObjects() - 1; i >= 0; i--)
	{
		btCollisionObject* obj = dynamicsWorld->getCollisionObjectArray()[i];
		btRigidBody* body = btRigidBody::upcast(obj);
		if (body && body->getMotionState())
		{
			delete body->getMotionState();
		}
		dynamicsWorld->removeCollisionObject(obj);
		delete obj;
	}

	//delete collision shapes
	for (int j = 0; j < collisionShapes.size(); j++)
	{
		btCollisionShape* shape = collisionShapes[j];
		collisionShapes[j] = 0;
		delete shape;
	}
	delete dynamicsWorld;

	//delete solver
	delete solver;

	//delete broadphase
	delete overlappingPairCache;

	//delete dispatcher
	delete dispatcher;

	delete collisionConfiguration;
}

PhysicsManager * PhysicsManager::getPhysicsManager()
{
	/*
	Singleton structure used from https://www.geeksforgeeks.org/singleton-design-pattern/
	*/
	if (singletonPM == nullptr) {
		static PhysicsManager physManager;
		singletonPM = &physManager;
	}
	return singletonPM;
}

void PhysicsManager::UpdateWorld(float delta)
{
	if (isStarted) {
		dynamicsWorld->stepSimulation(delta, 10);
	}
}

void PhysicsManager::InsertRigidBody(RendereableObject * thisObject, RigidBodyPrimitive typeofrb)
{
	if (isStarted) {
		btCollisionShape* colShape;
		float xScale = thisObject->GetScaleX();
		float yScale = thisObject->GetScaleY();
		float zScale = thisObject->GetScaleZ();
		//float scaleScale = 0.50f;
		Position_Bag* objectPosition = thisObject->GetPosition();
		switch (typeofrb) {
		case Sphere:
			colShape = new btSphereShape(btScalar(yScale));
			break;
		case Cube:

			colShape = new btBoxShape(btVector3(xScale, yScale,zScale));
			break;

		case Cylinder:
			return;
			break;

		case Capsule:
			return;
			break;

		case Cone:
			return;
			break;

		default:
			return;
			break;

		}

		btTransform startTransform;
		startTransform.setIdentity();

		btScalar mass = thisObject->mass;
		bool isDynamic = (mass != 0.f);

		btVector3 localInertia(0, 0, 0);
		if (isDynamic) {
			colShape->calculateLocalInertia(mass, localInertia);
		}

		startTransform.setOrigin(btVector3(objectPosition->location[0], objectPosition->location[1], objectPosition->location[2]));

		btDefaultMotionState* myMotionState = new btDefaultMotionState(startTransform); // might need to do something about then.
		btRigidBody::btRigidBodyConstructionInfo rbInfo(mass, myMotionState, colShape, localInertia);
		btRigidBody* body = new btRigidBody(rbInfo);
		collisionShapes.push_back(colShape);
		body->setRestitution(thisObject->restitution);
		body->setFriction(thisObject->friction);

		thisObject->myBody = body;
		thisObject->usePhysics = true;
		//thisObject->myObj = colShape;
		dynamicsWorld->addRigidBody(body);

	}

}

PhysicsManager * CreateStaticPM()
{
	return PhysicsManager::getPhysicsManager();
}
