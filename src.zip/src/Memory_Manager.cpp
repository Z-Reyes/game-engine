#include "Memory_Manager.h"

MemoryManager* MemoryManager::singletonMM = nullptr;

MemoryManager * MemoryManager::getMemoryManager()
{
	/*
	Singleton structure used from https://www.geeksforgeeks.org/singleton-design-pattern/
	*/
	// TODO: insert return statement here
	if (singletonMM == nullptr) {
		static MemoryManager memManager;
		singletonMM = &memManager;
	}
		return singletonMM;
	
}

MemoryManager* CreateStaticMM()
{
	return MemoryManager::getMemoryManager();
}


//MemoryManager::MemoryManager()
//{
//	Directions = new std::vector<Zec3*>();
//	Positions = new std::vector<Zos*>();
//	Matrices = new std::vector<Zat4*>();
//	Quaternions = new std::vector<Quaternion*>();
//}

MemoryManager::~MemoryManager()
{
	//Will need to destroy list contents?
}

void MemoryManager::StartUp(int numVertices, int numPositions, int numMatrices, int numQuads)
{
		isStarted = true;
		Directions = new std::vector<Zec3*>();
		Positions = new std::vector<Zos*>();
		Matrices = new std::vector<Zat4*>();
		Quaternions = new std::vector<Quaternion*>();

	maxVertices = numVertices;
	maxMatrices = numMatrices;
	maxPositions = numPositions;
	maxQuaternions = numQuads;
	rawDirections = new Zec3[numVertices];
	rawPositions = new Zos[numPositions];
	rawMatrices = new Zat4[numMatrices];
	rawQuaternions = new Quaternion[numQuads];

	//Now we need to fill the vectors with pointers.
	
	//Fill up Directions.
	for (int i = 0; i < numVertices; i++) {
		Directions->push_back(&rawDirections[i]);
	}

	for (int i = 0; i < numPositions; i++) {
		Positions->push_back(&rawPositions[i]);
	}

	for (int i = 0; i < numMatrices; i++) {
		Matrices->push_back(&rawMatrices[i]);
	}

	for (int i = 0; i < numQuads; i++) {
		Quaternions->push_back(&rawQuaternions[i]);
	}

	LoadDefaults();

}

void MemoryManager::LoadDefaults()
{
	if (isStarted) {
		AddTexture("res/Textures/default.jpg", "default_texture");



		AddModel("res/default_shapes/Cube.zShape", "Cube", false);
		AddModel("res/default_shapes/Pyramid.zShape", "Pyramid", false);
		   
		AddModel("res/default_shapes/Quad.zShape", "Quad", false);
		AddModel("res/default_shapes/Sphere.zShape", "Sphere", false);

	}
}

void MemoryManager::AddModel(std::string filepath, std::string shapeID, bool useAssimp)
{
	if (!useAssimp) {
		Model* toBeInserted = new Model();
		toBeInserted->AppendShape(new RenderableShape(filepath, false));
		shapeList.insert({ shapeID, toBeInserted });
	}
	else {
		Model* toBeInserted = new Model();
		toBeInserted->LoadModelViaAssimp(filepath);
		shapeList.insert({ shapeID, toBeInserted });
	}
}

void MemoryManager::AddTexture(std::string filepath, std::string textureID)
{
	textureList.insert({ textureID, new Texture(filepath) });
}

void MemoryManager::AddMaterial(std::string mId, material* insert) {
	materialList.insert({ mId, insert });
}

material* MemoryManager::RequestMaterial(std::string identifier) {
	if (isStarted) {
		try {
			material* mat = materialList.at(identifier);
			return mat;
		}
		catch (const std::out_of_range& e) {
			std::cerr << "Name does not exist in texture list" << "\n";
			return nullptr;
		}
	}
	else {
		return nullptr;
	}
}

Texture * MemoryManager::RequestTexture(std::string identifier)
{
	
	if (isStarted) {
		try {
			Texture* tex = textureList.at(identifier);
			return tex;
		}
		catch (const std::out_of_range& e) {
			std::cerr << "Name does not exist in texture list" << "\n";
			return nullptr;
		}
	}
	else {
		return nullptr;
	}
}

Model * MemoryManager::RequestModel(std::string identifier)
{
	if (isStarted) {
		try {
			Model* rs = shapeList.at(identifier);
			return rs;
		}
		catch (const std::out_of_range& e) {
			std::cerr << "Name does not exist in shape list" << "\n";
			return nullptr;
		}
	}
	else {
		return nullptr;
	}
}

void MemoryManager::IncrementAutoTexture()
{
	autoTextures++;
}

void MemoryManager::ResetAutoTexture()
{
	autoTextures = 0;
}

unsigned int MemoryManager::GetAutoTexture()
{
	return autoTextures;
}


void MemoryManager::CompareSize(int sizeV3, int sizePos, int sizeMat, int sizeQuad) {
	if (sizeV3 < maxVertices) {
		std::cout << "Fewer Vectors exist in list than was originally allocated. ";
	}

	if (sizePos < maxPositions) {
		std::cout << "Fewer Positions exist in list than was originally allocated. ";
	}

	if (sizeMat < maxMatrices) {
		std::cout << "Fewer Matrices exist in list than was originally allocated. ";
	}

	if (sizeQuad < maxQuaternions) {
		std::cout << "Fewer Quaternions exist in list than was originally allocated." << std::endl;
	}

}
void MemoryManager::Shutdown()
{
	if (isStarted) {
		CompareSize(Directions->size(), Positions->size(), Matrices->size(), Quaternions->size());
		isStarted = false;
		delete Directions;
		delete Positions;
		delete Matrices;
		delete Quaternions;

		delete[] rawDirections;
		delete[] rawPositions;
		delete[] rawMatrices;
		delete[] rawQuaternions;
		
		for (auto iter = textureList.begin(); iter != textureList.end(); iter++) {
			Texture* val = iter->second;
			delete val;
		}
		textureList.clear();
		for (auto iter = shapeList.begin(); iter != shapeList.end(); iter++) {
			Model* val = iter->second;
			delete val;
		}
		shapeList.clear();
		for (auto iter = materialList.begin(); iter != materialList.end(); iter++) {
			material* val = iter->second;
			delete val;
		}
		materialList.clear();
		ResetAutoTexture();

		//See if we need a delete statement for shape and texture list.

	}
}

Zec3 * MemoryManager::RequestZec3()
{
	if (isStarted) {
	//std::cout << "Size is: " << Directions->size() << std::endl;
	if (!Directions->empty()) {
		Zec3* potential = Directions->back();
		Directions->pop_back();
		//std::cout << "Size is now: " << Directions->size() << std::endl;
		return potential;
	}
	else {
		return nullptr;
	}
	}
	else {
		std::cout << "Memory Manager has not been initialized!" << std::endl;
		return nullptr;
	}
}

void MemoryManager::ReturnZec3(Zec3 * returnee)
{
	if (isStarted) {
		Directions->push_back(returnee);
	}
	else {
		std::cout << "Memory Manager has not been initialized!" << std::endl;
	}
}

Zat4 * MemoryManager::RequestZat4()
{
	if (isStarted) {
		if (!Matrices->empty()) {
			Zat4* potential = Matrices->back();
			Matrices->pop_back();
			return potential;
		}
		else {
			return nullptr;
		}
	}
	else {
		std::cout << "Memory Manager has not been initialized!" << std::endl;
		return nullptr;
	}
}

void MemoryManager::ReturnZat4(Zat4 * returnee)
{
	if (isStarted) {
		Matrices->push_back(returnee);
	}
	else {
		std::cout << "Memory Manager has not been initialized!" << std::endl;
	}
}

Zos * MemoryManager::RequestZos()
{
	if (isStarted) {
		if (!Positions->empty()) {
			Zos* positions = Positions->back();
			Positions->pop_back();
			return positions;
		}
		else {
			return nullptr;
		}
	}
	else {
		std::cout << "Memory Manager has not been initialized!" << std::endl;
		return nullptr;
	}
}

void MemoryManager::ReturnZos(Zos * returnee)
{
		if (isStarted) {
			Positions->push_back(returnee);
		}
		else {
			std::cout << "Memory Manager has not been initialized!" << std::endl;
		}
	
}

Quaternion * MemoryManager::RequestQuad()
{
	if (isStarted) {
		if (!Quaternions->empty()) {
			Quaternion* potential = Quaternions->back();
			Quaternions->pop_back();
			return potential;
		}
		else {
			return nullptr;
		}
	}
	else {
		std::cout << "Memory Manager has not been initialized!" << std::endl;
		return nullptr;
	}
}

void MemoryManager::ReturnQuad(Quaternion * returnee)
{
	if (isStarted) {
		Quaternions->push_back(returnee);
	}
	else {
		std::cout << "Memory Manager has not been initialized!" << std::endl;
	}
}

MemoryManager::MemoryManager() {

}



