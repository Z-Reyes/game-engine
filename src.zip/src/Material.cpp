#include "Material.h"

material::material()
{
	float baseValue = 0.75f;
	SetAmbient(baseValue, baseValue, baseValue,1.0f);
	SetDiffuse(baseValue, baseValue, baseValue, 1.0f);
	SetSpecular(baseValue, baseValue, baseValue, 1.0f);
	shiny = baseValue;
	
}

void material::ResetIndex(int index)
{
	switch (index) {
	case 0:
		for (int i = 0; i < 4; i++) {
			ambient[i] = 0.0f;
		}
		break;
	case 1:
		for (int i = 0; i < 4; i++) {
			diffuse[i] = 0.0f;
		}
		break;
	case 2:
		for (int i = 0; i < 4; i++) {
			specular[i] = 0.0f;
		}
		break;
	case 3:
		shiny = 0.0f;
		break;
	default:
		break;
	}
}

void material::ResetAmbient()
{
	ResetIndex(0);
}

void material::ResetDiffuse()
{
	ResetIndex(1);
}

void material::ResetSpecular()
{
	ResetIndex(2);
}

void material::ResetShiny()
{
	shiny = 0.0f;
}

void material::ResetAll()
{
	for (int i = 0; i < 4; i++) {
		ResetIndex(i);
	}
}

void material::SetAmbient(float * aValues)
{
	//if (sizeof(aValues) / sizeof(float) == 4) {
		ambient[0] = aValues[0];
		ambient[1] = aValues[1];
		ambient[2] = aValues[2];
		ambient[3] = aValues[3];
	//}
	//else {
		//Do nothing
	//}
}

void material::SetAmbient(float av1, float av2, float av3, float av4)
{
	float ambientValues[4];
	ambientValues[0] = av1;
	ambientValues[1] = av2;
	ambientValues[2] = av3;
	ambientValues[3] = av4;
	SetAmbient(ambientValues);

}

void material::SetDiffuse(float * dValues)
{
	//if (sizeof(dValues) / sizeof(float) == 4) {
		diffuse[0] = dValues[0];
		diffuse[1] = dValues[1];
		diffuse[2] = dValues[2];
		diffuse[3] = dValues[3];
	//}
	//else {
		//Do nothing
	//}
}

void material::SetDiffuse(float dv1, float dv2, float dv3, float dv4)
{
	float diffuseValues[4];
	diffuseValues[0] = dv1;
	diffuseValues[1] = dv2;
	diffuseValues[2] = dv3;
	diffuseValues[3] = dv4;
	SetDiffuse(diffuseValues);
}

void material::SetSpecular(float * sValues)
{
	//if (sizeof(sValues) / sizeof(float) == 4) {
		specular[0] = sValues[0];
		specular[1] = sValues[1];
		specular[2] = sValues[2];
		specular[3] = sValues[3];
	//}
	//else {
		//Do nothing
	//}
}

void material::SetSpecular(float sv1, float sv2, float sv3, float sv4)
{
	float specularValues[4];
	specularValues[0] = sv1;
	specularValues[1] = sv2;
	specularValues[2] = sv3;
	specularValues[3] = sv4;
	SetSpecular(specularValues);
}

void material::SetShiny(float shine)
{
	shiny = shine;
}
