#pragma once
#include "Math_Components\Zat4.h"
#include "Math_Components\Quaternion.h"
#include "Math_Components\Zos.h"
#include "Math_Components\Zec3.h"
#include "AudioSource.h"
#include "Texture.h"
#include "Renderable_Shape.h"
#include "Model.h"
#include "Material.h"
#include "Light.h"
#include <vector>
#include <iostream>
#include <string>
#include <unordered_map>
//followed template in slides.

/*
The MemoryManager class acts as a manager of our popular data types (Quaternions, Zec3, etc).
It follows a library design, where the MemoryManager holds a certain amount of each data type.
Other components have to request datatypes for themselves from the MemoryManager.
After that component uses the datatype, they should return it to the MemoryManager.
The MemoryManager must be started up at the beginning, before use. It must also be shutdown after use.
Currently, upon shutdown, the MemoryManager doesn't delete the pointers it has given out and hasn't received back.
*/
class MemoryManager {
public:
	/*
	Returns a static MemoryManager.
	*/

	//MemoryManager();
	/*
	Unused at this point.
	*/
	//~MemoryManager();

	/*
	Our StartUp method. Allocates numVertices Zec3s, numPositions Zos's, numMatrices Zat4s, and numQuads Quaternions.
	*/
	void StartUp(int numVertices, int numPositions, int numMatrices, int numQuads);
	/*
	Shutdown method. Deallocates previously allocated memory.
	*/
	void Shutdown();
	/*
	Requests a Zec3 from the MemoryManager repository.
	Upon success, a Zec3 pointer is returned.
	If repository is empty, nullptr is returned.
	*/
	Zec3* RequestZec3();
	/*
	Returns a Zec3 pointer (returnee) to the MemoryManager repository.
	*/
	void ReturnZec3(Zec3* returnee);
	/*
	Requests a Zat4 from the MemoryManager repository.
	Upon success, a Zat4 pointer is returned.
	If repository is empty, nullptr is returned.
	*/
	Zat4* RequestZat4();
	/*
	Returns a Zat4 pointer (returnee) to the MemoryManager repository.
	*/
	void  ReturnZat4(Zat4* returnee);
	/*
	Requests a Zos from the MemoryManager repository.
	Upon success, a Zos pointer is returned.
	If repository is empty, nullptr is returned.
	*/
	Zos* RequestZos();
	/*
	Returns a Zos pointer (returnee) to the MemoryManager repository.
	*/
	void  ReturnZos(Zos* returnee);
	/*
	Requests a Quaternion from the MemoryManager repository.
	Upon success, a Quaternion pointer is returned.
	If repository is empty, nullptr is returned.
	*/
	Quaternion* RequestQuad();
	/*
	Returns a Quaternion pointer (returnee) to the MemoryManager repository.
	*/
	void  ReturnQuad(Quaternion* returnee);
	/*
	Loads the default shapes and textures so rendering can begin. Addition of more default shapes can be accomplished
	*/
	void LoadDefaults();

	/*
	Loads a RenderableShape into the MemoryManager, allowing that shape to be drawn. Shape can be requested
	via its shapeID and RequestShape(shapeID);
	*/
	void AddModel(std::string filepath, std::string shapeID, bool useAssimp);

	/*
	Loads a Texture into the MemoryManager, allowing that texture to be drawn. Texture can be requested
	via its textureID and RequestTexture(textureID)
	*/
	void AddTexture(std::string filepath, std::string textureID);
	
	/*
	Requests a texture (identified with identifier) from the MemoryManager. Returns nullptr if texture does not
	exist in the MemoryManager.
	*/
	Texture* RequestTexture(std::string identifier);
	/*
	Returns a pointer to the MemoryManager singleton.
	*/
	static MemoryManager* getMemoryManager();
	/*
	Requests a model (identified with identifier) from the MemoryManager. Returns nullptr if shape does not
	exist in the MemoryManager.
	*/
	Model* RequestModel(std::string identifier);
	void IncrementAutoTexture();
	void ResetAutoTexture();
	unsigned int GetAutoTexture();
	void AddMaterial(std::string mId, material* insert);
	material* RequestMaterial(std::string identifier);
private:
	int maxVertices, maxMatrices, maxQuaternions, maxPositions;
	MemoryManager();
	~MemoryManager();
	bool isStarted = false;
	//MemoryManager();
	Zec3* rawDirections;
	Zos* rawPositions;
	Zat4* rawMatrices;
	Quaternion* rawQuaternions;
	std::vector<Zec3*>* Directions;
	std::vector<Zos*>* Positions;
	std::vector<Zat4*>* Matrices;
	std::vector<Quaternion*>* Quaternions;
	void CompareSize(int sizeV3, int sizePos, int sizeMat, int SizeQuad);
	std::unordered_map<std::string, Model*> shapeList;
	std::unordered_map<std::string, Texture*> textureList;
	std::unordered_map<std::string, material*> materialList;
	static MemoryManager* singletonMM;
	unsigned int autoTextures;
	//std::vector<light> lightMemoryQueue;
	//std::vector<material> materialQueue;
	

};
/*
A function that returns the same result as the MemoryManager::getMemoryManager() method.
*/
MemoryManager* CreateStaticMM();