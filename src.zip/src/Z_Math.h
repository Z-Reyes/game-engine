#pragma once
#include "Math_Components\Zec3.h"
#include "Math_Components\Zat4.h"
#include "Math_Components\Zos.h"
#include "Math_Components\Quaternion.h"
#include <xmmintrin.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
/*
Author: Zachary Reyes
Z_Math.h contains the prototypes for the math functions in my math library
It provides functions for vector math, position math, quaternion math, and matrix math.
More will probably be added as necessary.
*/

/*
A union type used internally for our simd math operations.
*/
union Sse_get {
	__m128 reg;
	float re[4];
};
/*
operator overloading function for returning the negative of a Zec3
*/
Zec3 operator-(Zec3 &a);
/*
operator overloading function for returning the negative of a Zec3
*/
Zos operator-(Zos &a);


/*
Subtracts 2 Zos coordinate pairs and returns the result in a Zec3.
Input: 2 Zos objects. Source is the starting point, destination is the final point.
Output: A Zec3 whose vector represents the distance and orientation between the two points.
*/
Zec3 PositionPositionSubtraction(Zos &source, Zos &destination);
/*
Operator overloading to make PositionPositionSubtraction easier to call.
*/
Zec3 operator-(Zos &source, Zos &destination);

/*
Adds a vector coordinate value onto a source point, producing a new Zos point.
Input: A Zos and Zec3 object. Point is the starting point, and direction is the new heading of that point.
Output: A Zos that represents the coordinates of the Zos's coordinates added with the Zec3's coordinates.
*/
Zos PositionDirectionAddition(Zos &point, Zec3 &direction);
/*
Operator overloading to make PositionDirectionAddition easier to call.
*/
Zos operator+(Zos &source, Zec3 &direction);

/*
Subtracts 2 Directions from one another, producing a new direction
Input: 2 Zec3 objects. d1 is the first point, d2 is the second point. Subtracts d2 coordinates from d1.
Output: A Zec3 object with coordinates representing the subtraction between d2 and d1 coordinates.
*/
Zec3 DirectionDirectionSubtraction(Zec3 &d1, Zec3 &d2);
/*
Operator overloading to make DirectionDirectionSubtraction easier to call.
*/
Zec3 operator-(Zec3 &d1, Zec3 &d2);

/*
Adds 2 Directions to one another, producing a new direction.
Input: 2 Zec3 objects. d1 is the first point, d2 is the second point
Output: A Zec3 object with coordinates representing the addition between d1 and d2 coordinates.
*/
Zec3 DirectionDirectionAddition(Zec3 &d1, Zec3 &d2);

/*
Operator overloading to make DirectionDirectionAddition easier to call.
*/
Zec3 operator+(Zec3 &d1, Zec3 &d2);

/*
Multiplies a scalar value to the coordinates of a direction, producing a new direction.
Input: a float (which acts as the multiplier and a Zec3 source vector.
Output: A new Zec3 object with coordinates of source multiplied by multiplier.
*/
Zec3 ScalarDirectionMultiplication(float multiplier, Zec3 &source);
/*
Operator overloading to make calling ScalarDirectionMultiplication easier.
*/
Zec3 operator*(float multiplier, Zec3 &source);

/*
Multiplies a scalar value to the coordinates of a position producing a new position.
Input: a float (which acts as the multiplier and a Zos source position.
Output: A new Zos object with coordinates of source multiplied by multiplier.
*/
Zos ScalarPositionMultiplication(float multiplier, Zos &source);
/*
Operator overloading to make calling ScalarPositionMultiplication easier.
*/
Zos operator*(float multiplier, Zos &source);

/*
Calculates the magnitude of a source Direction.
Input: A Zec3 object.
Output: A float with the value of the magnitude of source.
*/
float Mag(Zec3 &source);

/*
Calculates the dot product of two source directions.
Input: 2 Zec3 objects.
Output: A float with the value of the dot product of the two Zec3.
*/
float operator*(Zec3 &a, Zec3 &b);
/*
Calculates the cross product of two source directions.
Input: 2 Zec3 objects.
Output: A Zec3 object with coordinates perpendicular to both a and b.
*/
Zec3 Cross(Zec3 &a, Zec3 &b);

/*
Normalizes a given direction.
Input: A Zec3 to normalize.
Output: A Zec3 object with a magnitude of 1.
*/
Zec3 Normalize(Zec3 &norm);

/*
Calculates the projection of one Direction onto another.
Input: Two Zec3 objects. unto is the unit vector being projected upon. onto is the vector projecting onto unto.
Output: A float value representing the length of the projection of onto onto unto.
*/
float Projection(Zec3 &unto, Zec3 &onto);
/*
Performs the Lerp function between two directions, using a float for the interpolation between the vectors.
Input: 2 Zec3 objects, and a beta value for interpolation.
Output:A Zec3 with the result of the interpolation between a + b.
*/
Zec3 Lerp(Zec3 &a, Zec3 &b, float beta);


/*
	The following are the matrix math functions included in my library
*/
/*
Not used currently.
*/
__m128 AddWithIntrinsics(const __m128 a, const __m128 b);

/*
Adds 2 matrices together and returns the result.
Input: 2 Zat4 objects.
Output: A Zat4 with the result of ad1 + ad2.
*/
Zat4 AddMatrixMatrix(Zat4 &ad1, Zat4 &ad2);
/*
Operator overloading to make AddMatrixMatrix easier to call.
*/
Zat4 operator+(Zat4 &ad1, Zat4 &ad2);

/*
Multiplies a matrix with a Position_Bag object. Not meant to be used
by developer.
*/
Position_Bag MultiplyMatrixBag(Zat4 &b, Position_Bag *store);

/*
Multiplies 2 4x4 matrices together and returns the result.
Input: 2 Zat4 objects. It is right-side based.
Output: A Zat4 object with result of the multiplication.
*/
Zat4 MultiplyMatrixMatrix(Zat4 &ad1, Zat4 &ad2);
/*
Operator overloading to make calling MultiplyMatrixMatrix easier to call.
*/
Zat4 operator*(Zat4 &a, Zat4 &b);
/*
Multiplies A Direction with a 4x4 matrix.
Input: A Zec3 and Zat4 object. Zec3's are viewed as 4x1 matrix, so right-hand matrix multiplication is used.
Output: A Zec3 object with coordinates resulting from the multiplication.
*/
Zec3 MultiplyDirectionMatrix(Zec3 &a, Zat4 &b);
/*
Operator overloading to make calling MultiplyDirectionMatrix easier to call.
*/
Zec3 operator* (Zat4 &b, Zec3 &a);

/*
Multiplies a position with a matrix.
Input: A Zos and a Zat4 object. Zos is also 4x1 matrix, so right-hand matrix multiplication is used.
Output: A Zos object with coordinates resulting from the multiplication.
*/
Zos MultiplyPositionMatrix(Zos &a, Zat4 &b);
/*
Operator overloading to make MultiplyPositionMatrix easier to call.
*/
Zos operator* (Zat4 &b, Zos &a);

/*
Multiplies A Direction with a 4x4 matrix. This version uses simd math.
Input: A Zec3 and Zat4 object. Zec3's are viewed as 4x1 matrix, so right-hand matrix multiplication is used.
Output: A Zec3 object with coordinates resulting from the multiplication.
*/
Zec3 QuickMultiplyDirectionMatrix(Zec3 &a, Zat4 &b);
/*
Multiplies 2 4x4 matrices together and returns the result. This version uses simd math, making it faster.
Input: 2 Zat4 objects. It is right-side based.
Output: A Zat4 object with result of the multiplication.
*/
Zat4 QuickMultiplyMatrixMatrix(Zat4 &a, Zat4 &b);

/*
Returns a 4x4 transformation.
Input: 3 floats. Their values correspond to the translation amount given in that dimension (given by their name).
Output: A translation matrix specified by the input.
*/
Zat4 Translate(float x, float y, float z);

/*
Calculates the transpose of a 4x4 matrix.
Input: Zat4 object to be transposed.
Output: The transposed matrix as a Zat4 object.
*/
Zat4 Transpose(Zat4 &a);
/*
Operator overloading to make calling Transpose easier.
*/
Zat4  operator$(Zat4 &a);
/*
Multiplies 2 quaternions together, returning the result.
Input: 2 Quaternion objects
Output: A Quaternion object with the coordinates representing the multiplication result.
*/
Quaternion MultiplyQuaternions(Quaternion &a, Quaternion &b);
/*
Operator overloading to make calling MultiplyQuaternions easier.
*/
Quaternion operator*(Quaternion &a, Quaternion &b);
/*
Rotates the given input vector around a vector axis by a given number of radians.
Input: 2 Zec3 objects and a float. input is the Zec3 to be rotated, axis is the rotation of axis, and radians is the amount of rotation (in radians).
Output: A Zec3 object with the coordinates resulting from the multiplication.
*/
Zec3 RotateWQuaternion(Zec3 &input, Zec3 &axis, float radians);
/*
Rotates the given input vector around a vector axis by a given number of radians.
Input: 1 Zec3 objects and 4 floats. input and radians are the same as in RotateWQuaternion, but x, y, and z are the coordinates of the desired axis of rotation.
Output: A Zec3 object with the coordinates resulting from the multiplication.
*/
Zec3 RotateWQuaternion(Zec3 &input, float x, float y, float z, float radians);

/*
Creates a rotation matrix around an arbitrary axis.
Input: A Zec3 describing the axis of rotation, and radians, the amount of radians to rotate around axis_of_rotation.
Output: A Zat4 representing the final rotation around axis_of_rotation by radian amount.
*/
Zat4 Rotate(Zec3 axis_of_rotation, float radians);

/*
Converts a given quaternion to a rotation matrix.
Input: in is a Quaternion that represents a desired rotation.
Output: A Zat4 conversion of the rotations defined by the quaternion.
*/
Zat4 QuaternionToRM(Quaternion &in);

/*
Creates a Translation matrix from a Zos translate.
Input: A Zos defining the desired translation point.
Output: a translation matrix to the positions in translate.
*/
Zat4 Translate(Zos translate);

Zat4 Translate(Zec3 translate);
/*
Calculates the inverse of a unit quaternion.
Input: A Quaternion object a.
Output: The inverse of a.
*/
Quaternion QuaternionInverse(Quaternion &a);
/*
Calculates the sum of the coordinates of two Quaternions.
Input: 2 Quaternion objects.
Output: A quaternion with coordinates representing the sum of a and b.
*/
Quaternion AddQuaternionQuaternion(Quaternion &a, Quaternion &b);
/*
Operator overloading to make calling AddQuaternionQuaternion easier.
*/
Quaternion operator+(Quaternion &a, Quaternion &b);

/*
Multiplies a scalar value to a quaternion.
Input: A Quaternion object and a float multiplier.
Output: A Quaternion with coordinates representing the result of the multiplication.
*/
Quaternion MultiplyScalarQuaternion(float multiplier, Quaternion&a);
/*
Operator overloading to make calling MultiplyScalarQuaternion easier.
*/
Quaternion operator*(float multiplier, Quaternion &a);
/*
Calculates the magnitude of the components of a quaternion.
Input: A Quaternion a.
Output: A float value representing the magnitude of a.
*/
float Mag(Quaternion &a);
/*
Performs the Lerp function between two Quaternions, used for smoother rotations.
Input: Two Quaternion objects, and a float value for the interpolation.
Output: A Quaternion object with coordinates representing the result of the Lerp.
*/
Quaternion Lerp(Quaternion &a, Quaternion&b, float beta);

/*
Converts a type Zec3 to Zos. Shouldn't be relied on too heavily.
Input: Zec3 object.
Output: Zos object.
*/
Zos ConvertZecToZos(Zec3 &a);
/*
Converts a type Zos to Zec3. Shouldn't be relied on too heavily.
Input: Zos object.
Output: Zec3 object.
*/
Zec3 ConvertZosToZec3(Zos &a);

/*
Creates a rotation vector around the z axis.
Input: A float radians representing the rotation amount around this vector.
Output: A rotation matrix with rotation radians about the z axis.
*/
Zat4 RotateZAxis(float radians);
/*
Creates a rotation vector around the x axis.
Input: A float radians representing the rotation amount around this vector.
Output: A rotation matrix with rotation radians about the x axis.
*/
Zat4 RotateXAxis(float radians);
/*
Creates a rotation vector around the y axis.
Input: A float radians representing the rotation amount around this vector.
Output: A rotation matrix with rotation radians about the y axis.
*/
Zat4 RotateYAxis(float radians);

/*
Calculates a random number between the lowerBound and higherBound.
Input: Two int types.
Output: A random number between lowerBound (inclusive) and higherBound (exclusive).
*/
float RandomNum(int lowerBound, int higherBound);
/*
Function to initialize RNG with a seed. Very basic at this point.
*/
void InitializeRNGSeed();
/*
Returns an identity matrix.
*/
Zat4 IdentityMat();
/*
A function that returns a very basic perspective projection matrix. Mainly used for testing purposes at this point.
*/
Zat4 Perspective(float fov, float nearClip, float farClip);
Zat4 OpenGlPerspective(float fov, float nearClip, float farClip, float aspectRatio);