#pragma once
#include "Renderable_Shape.h"
#include <assimp\Importer.hpp>
#include <assimp\scene.h>
#include <assimp\postprocess.h>
#include <vector>
#include <string>
/*
A capping structure for handling multiple meshes.
*/
class Model {
public: 
	/*
	Appends a RenderableShape to this model's shape queue (meshes)
	*/
	void AppendShape(RenderableShape* append);
	/*
	Returns the number of meshes that make up this model.
	*/
	int GetNumShapes();
	
	/*
	Accesses a mesh at that index location. if the index location is greater than the size of the list, returns nullptr.
	*/
	RenderableShape* GetShapeAtIndex(int index);

	void LoadModelViaAssimp(std::string filepath);
	bool GetIsRenderable();
	Model();
	~Model();
private:
	int numberShapes;
	bool isRenderable;
	std::vector<RenderableShape*> shapeQueue;

	
};