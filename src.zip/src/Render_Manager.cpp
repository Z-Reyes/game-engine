#include "Render_Manager.h"
#include <iostream>

RenderManager* RenderManager::singletonRM = nullptr;

void GLClearError()
{
	//declare all the errors
	while (glGetError() != GL_NO_ERROR);
}

bool GLLogCall(const char* function, const char* file, int line)
{
	while (GLenum error = glGetError()) {
		std::cout << "[OPENGL Error] (" << error << ")" << " " << function << " " << file << ":" << line << std::endl;
		return false;
	}
	return true;
}

RenderManager * RenderManager::get()
{
	if (singletonRM == nullptr) {
		static RenderManager renderManager;
		singletonRM = &renderManager;
		//renderManager.LoadDefaultShaders();
	}
	return singletonRM;
}

void RenderManager::LoadDefaultShaders() {
	if (isStarted) {
		AddShader("res/shaders/DefaultT1.shader", "default_T1_shader");
		AddShader("res/shaders/DefaultT2.shader", "default_T2_shader");
		AddShader("res/shaders/DefaultT3.shader", "default_T3_shader");
		AddShader("res/shaders/Default_Animation.shader", "default_AT1_shader");
	}
}

void RenderManager::DrawOpaqueRenderQueue()
{

	if (isStarted) {
		MemoryManager* mm = MemoryManager::getMemoryManager();
		GLCall(glClearColor(0.0f, 0.0f, 0.0f, 1.0f));
		glClear(GL_DEPTH_BUFFER_BIT);
		glClear(GL_COLOR_BUFFER_BIT);
		renderCam.AssignAllChanges();
		DrawSkyFrame();
		//mm.RequestZos();
		//Put draw call for skyFrame here.
		for (int i = 0; i < opaqueRenderQueue.size(); i++) {
			//std::cout << "Making draw call" << std::endl;
			//Get shape.
			RendereableObject *object_data = opaqueRenderQueue.at(i);
			Model* currentModel = mm->RequestModel(object_data->GetShapeID());
			
			if (currentModel == nullptr || !currentModel->GetIsRenderable()) {
				//std::cout << "Model cannot be drawn" << std::endl;
				break;
			}

			int numIterations = currentModel->GetNumShapes();
			for (int renderLoopIterations = 0; renderLoopIterations < numIterations; renderLoopIterations++) {
				RenderableShape* shape_to_be_rendered = currentModel->GetShapeAtIndex(renderLoopIterations);

				//Get Shader.
				Shader * shader_to_be_used = RequestShader(object_data->GetShaderID());
				//std::cout << object_data->GetShapeID() << std::endl;

				//Get desired rendering tier
				if (shader_to_be_used != nullptr && shape_to_be_rendered != nullptr) {
					unsigned int shapeTier = shape_to_be_rendered->GetTier();
					unsigned int desiredTier = object_data->GetDesiredTier();
					unsigned int shaderTier = shader_to_be_used->GetTier();

					//Choose the lower of the two (shape and desired) then compare to shader tier. Pick the lower of the two.
					unsigned int finalTier = desiredTier;
					//std::cout << "Desired tier is: " << desiredTier << std::endl;
					//std::cout << "Shape tier is: " << shapeTier << std::endl;
					//std::cout << "Shader tier is: " << shaderTier << std::endl;
					if (finalTier > shapeTier) {
						finalTier = shapeTier;
					}
					if (finalTier >= shaderTier && finalTier != 0) {
						finalTier = shaderTier;
						//std::cout << "Final tier is " << finalTier << std::endl;
						//Bind the vao.
						GLCall(glBindVertexArray(shape_to_be_rendered->ReturnVAO()));
							//Bind the Shader.
							shader_to_be_used->Bind();
						//We are guaranteed to at least have the MVP, so set that uniform asap.
						Zat4 model = object_data->ProduceModelMatrix();
						shader_to_be_used->SetUniformMat4f("u_MVP", projectionMatrix * renderCam.GetTRMatrix() * model);
						//Then check if tier >= 2. if it is, then we set the texture. For now, just replace texture location 0.

						//std::cout << "Final tier is " << finalTier << std::endl;
						//std::cout << "Num vertices is " << shape_to_be_rendered->GetVertexSize() << std::endl;
						if (finalTier >= 2) {

							Texture* desired_texture;
							if (object_data->GetUseMyTexture()) {
								desired_texture = mm->RequestTexture(object_data->GetTexID());
							}
							else {
								desired_texture = mm->RequestTexture(shape_to_be_rendered->GetShapeTexture());
								//std::cout << "Texture name is " << shape_to_be_rendered->GetShapeTexture() << std::endl;
							}

							if (desired_texture != nullptr) {
								desired_texture->Bind(1);
								shader_to_be_used->SetUniform1i("u_Texture", 1);
								
							}
							else {
							//	std::cout << "Oops that texture can't be found: " << shape_to_be_rendered->GetShapeTexture() << std::endl;
							}
						}
						//If tier >= 3, we would do materials or normals, but don't worry about that for now.
						//GLCall(glDrawArrays(GL_TRIANGLES, 0, shape_to_be_rendered->GetVertexSize()));

						if (finalTier >= 3) {
						//	std::cout << "using a tier 3 shape" << std::endl;
							//load model matrix.
							shader_to_be_used->SetUniformMat4f("m_matrix", model);
							//Now we get the light.


							Zos camPos = renderCam.GetCameraLocation();
							float camPosRaw[3] = {camPos.GetPosition()->location[0], camPos.GetPosition()->location[1], camPos.GetPosition()->location[2]};
							//std::cout << lightToBeUsed->ambientLight[0] << std::endl;
							shader_to_be_used->SetUniform3fv("viewPos", camPosRaw);

							if (!lightQueue.empty()) {

								int myIndex = 0;
								if (lightQueue.at(0)->myType == directional) {
									light *lightToBeUsed1 = lightQueue.at(myIndex);
									shader_to_be_used->SetUniform4fv("dirLight.ambient", lightToBeUsed1->ambientLight);
									shader_to_be_used->SetUniform4fv("dirLight.diffuse", lightToBeUsed1->diffuseLight);
									shader_to_be_used->SetUniform4fv("dirLight.specular", lightToBeUsed1->specularLight);
									shader_to_be_used->SetUniform3fv("dirLight.direction", lightToBeUsed1->position);
									myIndex++;
								}
								for (int lightIteration = 0; lightIteration < maxPositional; lightIteration++) {
									//std::string index = std::stoi(lightIteration);
									int potentialIndex = lightIteration + myIndex;
									//std::cout << "Potential index before adjustment " << potentialIndex << std::endl;
									//std::cout << "Additive is " << numPositional + numDirectional << std::endl;
									if (potentialIndex >= numPositional + numDirectional) {
										potentialIndex = (numPositional + myIndex) - 1;
									}
									//std::cout << "potential index is " << potentialIndex << std::endl;
									light* lightToBeUsed2 = lightQueue.at(potentialIndex);
									std::string ourIndex = std::to_string(lightIteration);
									std::string varName = "pointLights[" + ourIndex + "].constant";
									shader_to_be_used->SetUniform1f(varName, lightToBeUsed2->constant);
									varName = "pointLights[" + ourIndex + "].linearVal";
									shader_to_be_used->SetUniform1f(varName, lightToBeUsed2->linear);
									varName = "pointLights[" + ourIndex + "].quadratic";
									shader_to_be_used->SetUniform1f(varName, lightToBeUsed2->quadratic);

									varName = "pointLights[" + ourIndex + "].position";
									shader_to_be_used->SetUniform3fv(varName, lightToBeUsed2->position);

									varName = "pointLights[" + ourIndex + "].ambient";
									shader_to_be_used->SetUniform4fv(varName, lightToBeUsed2->ambientLight);
									varName = "pointLights[" + ourIndex + "].diffuse";
									shader_to_be_used->SetUniform4fv(varName, lightToBeUsed2->diffuseLight);
									varName = "pointLights[" + ourIndex + "].specular";
									shader_to_be_used->SetUniform4fv(varName, lightToBeUsed2->specularLight);
								}
								/*
								shader_to_be_used->SetUniform4fv("globalAmbient", lightToBeUsed->ambientAura);
								shader_to_be_used->SetUniform4fv("light.ambient",  lightToBeUsed->ambientLight);
								shader_to_be_used->SetUniform4fv("light.diffuse",  lightToBeUsed->diffuseLight);
								shader_to_be_used->SetUniform4fv("light.specular", lightToBeUsed->specularLight);
								shader_to_be_used->SetUniform3fv("light.position", lightToBeUsed->position);
								shader_to_be_used->SetUniform1f("light.constant", lightToBeUsed->constant);
								shader_to_be_used->SetUniform1f("light.linearVal", lightToBeUsed->linear);
								shader_to_be_used->SetUniform1f("light.quadratic", lightToBeUsed->quadratic);
								*/
							}
							shader_to_be_used->SetUniform4fv("material.ambient",  object_data->GetMyMaterial()->ambient);
							shader_to_be_used->SetUniform4fv("material.diffuse",  object_data->GetMyMaterial()->diffuse);
							shader_to_be_used->SetUniform4fv("material.specular", object_data->GetMyMaterial()->specular);
							shader_to_be_used->SetUniform1f("material.shininess", object_data->GetMyMaterial()->shiny);
						
						}

						GLCall(glDrawElements(GL_TRIANGLES, shape_to_be_rendered->GetVertexSize(), GL_UNSIGNED_INT, (void*)0));


						shader_to_be_used->Unbind();


					}
					else {
						//Can't do anything. don't draw.
						std::cout << "Cannot draw object!" << std::endl;
					}
				}
				else {
					//Do nothing
					std::cout << "Cannot find all components" << std::endl;
				}
			}


		}
	}
}

void RenderManager::Startup()
{
	isStarted = true;
	LoadDefaultShaders();

}

void RenderManager::Shutdown()
{
	if (isStarted) {


		//int shaderListSize = shaderList.size();
		//Assistance from https://en.cppreference.com/w/cpp/container/unordered_map/erase
		for (auto iter = shaderList.begin(); iter != shaderList.end(); iter++) {
			Shader* val = iter->second;
			delete val;
		}
		shaderList.clear();
		//int opaqueRenderQueueSize = opaqueRenderQueue.size();
		for (int i = 0; i < opaqueRenderQueue.size(); i++ ) {
			delete opaqueRenderQueue.at(i);
		}
 		opaqueRenderQueue.clear();
		for (int i = 0; i < lightQueue.size(); i++ ) {
			delete lightQueue.at(i);
		}
		lightQueue.clear();
		delete skyFrame; //DANGEROUS! DO NOT PUT SKYFRAME IN OPAQUERENDERQUEUE.
		isStarted = false;
	}
}



void RenderManager::AddShader(std::string filepath, std::string shaderID)
{
	if (isStarted) {
		shaderList.insert({ shaderID, new Shader(filepath) });
	}
}

Shader * RenderManager::RequestShader(std::string identifier)
{
	if (isStarted) {
		try {
			Shader* shader = shaderList.at(identifier);
			return shader;
		}
		catch (const std::out_of_range& e) {
			std::cerr << "Name does not exist in shader list" << "\n";
			return nullptr;
		}
	}
	else {
		return nullptr;
	}
}



void RenderManager::AppendOpaqueRenderQueue(RendereableObject * renderItem)
{
	if (isStarted) {
		opaqueRenderQueue.push_back(renderItem);
	}
}

void RenderManager::SetCameraMatrix(Camera cam)
{
	if (isStarted) {
	cameraMatrix = cam.GetTRMatrix();
	}
}

void RenderManager::SetProjectionMatrix(Zat4 proj)
{
	if (isStarted) {
		projectionMatrix = proj;
	}
}

void RenderManager::AppendLightQueue(light * insert)
{
	if (insert->myType == directional) {
		if (lightQueue.empty()) {
			lightQueue.push_back(insert);
			numDirectional++;
		}
	}
	else if (insert->myType == positional) {
		if (numPositional < maxPositional) {
			lightQueue.push_back(insert);
			numPositional++;
		}

	}

}

RenderManager* CreateStaticRM()
{
	return RenderManager::get();
}

void RenderManager::DeleteLightWithIdentifier(unsigned int id)
{
	int location = -1;
	int size = lightQueue.size();
	for (int i = 0; i < size; i++) {
		if (id == lightQueue.at(i)->identifier) {
			location = i;
			break;
		}
	}

	if (location != -1) {
		delete lightQueue.at(location);
		lightQueue.erase(lightQueue.begin() + location);
	}

}

void RenderManager::RenderAnimatedObject(RenderableShape * animatedShape, Zat4 * allJointTransforms, int numJoints)
{
	GLCall(glBindVertexArray(animatedShape->ReturnVAO()));
	Shader * shader_to_be_used = RequestShader("default_AT1_shader");
	shader_to_be_used->Bind();
	shader_to_be_used->SetUniformMat4f("u_VP", projectionMatrix * renderCam.GetTRMatrix());

	for (int i = 0; i < numJoints; i++) {
		std::string index = std::to_string(i);
		std::string varName = "jointTransforms[" + index + "]";
		shader_to_be_used->SetUniformMat4f(varName, allJointTransforms[i]);

	}
	//std::cout << "Num vertices is " << animatedShape->GetVertexSize() << std::endl;
	GLCall(glDrawElements(GL_TRIANGLES, animatedShape->GetVertexSize(), GL_UNSIGNED_INT, (void*)0));
	//GLCall(glDrawElements(GL_LINES, animatedShape->GetVertexSize(), GL_UNSIGNED_INT, (void*)0));


	shader_to_be_used->Unbind();
}

void RenderManager::SetSkyFrame(RendereableObject * desiredFrame)
{
	skyFrame = desiredFrame;
}
/*
Simply draws the Sky Frame without any depth testing. Object is rendered at a maximum of tier 2 at this point.
*/
void RenderManager::DrawSkyFrame()
{
	//If skyFrame exists, you draw it.
	if (skyFrame) {
		//std::cout << "Trying to draw skyframe " << std::endl;
		//first, turn off depth testing
		GLCall(glDisable(GL_DEPTH_TEST));

		//Now, we need to grab each of the different tier levels and select the lowest one for rendering.

		MemoryManager* mm = MemoryManager::getMemoryManager();
		Model* currentModel = mm->RequestModel(skyFrame->GetShapeID());
		RenderableShape* shape_to_be_rendered = currentModel->GetShapeAtIndex(0);

		//Get Shader.
		Shader * shader_to_be_used = RequestShader(skyFrame->GetShaderID());
		
		if (shader_to_be_used != nullptr && shape_to_be_rendered != nullptr) {
			unsigned int desiredTier = skyFrame->GetDesiredTier();
			unsigned int shaderTier = shader_to_be_used->GetTier();
			unsigned int shapeTier = shape_to_be_rendered->GetTier();

			unsigned int finalTier = desiredTier;
			if (shapeTier < shaderTier) {
				
				return;
			}
			if (desiredTier > shapeTier) {
				finalTier = shapeTier;
			}
			if (finalTier > 2) {
				//std::cout << "Shape tier is higher than shader tier" << std::endl;
				finalTier = 2;
			}

			GLCall(glBindVertexArray(shape_to_be_rendered->ReturnVAO()));
			//Bind the Shader.
			shader_to_be_used->Bind();
			Position_Bag* camPosition = renderCam.GetCameraLocation().GetPosition();
			Zat4 model = Translate(-camPosition->location[0], -camPosition->location[1], -camPosition->location[2]);
			shader_to_be_used->SetUniformMat4f("u_MVP", projectionMatrix * renderCam.GetTRMatrix() * model);

			if (finalTier >= 2) {
				
				Texture* desired_texture;
				if (skyFrame->GetUseMyTexture()) {
					desired_texture = mm->RequestTexture(skyFrame->GetTexID());
				}
				else {
					desired_texture = mm->RequestTexture(shape_to_be_rendered->GetShapeTexture());
					//std::cout << "Texture name is " << shape_to_be_rendered->GetShapeTexture() << std::endl;
				}

				if (desired_texture != nullptr) {
					//std::cout << "Binding texture to location 1" << std::endl;
					desired_texture->Bind(1);
					shader_to_be_used->SetUniform1i("u_Texture", 1);

				}
				else {
						std::cout << "Oops that texture can't be found: " << shape_to_be_rendered->GetShapeTexture() << std::endl;
				}
			}

			//std::cout << "Drawing shape" << std::endl;
			GLCall(glDrawElements(GL_TRIANGLES, shape_to_be_rendered->GetVertexSize(), GL_UNSIGNED_INT, (void*)0));
			GLCall(glEnable(GL_DEPTH_TEST));

			shader_to_be_used->Unbind();

		}


	}
}

RenderManager::RenderManager() {

}

RenderManager::~RenderManager() {
	//Empty for now.
}