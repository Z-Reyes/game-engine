#pragma once
#pragma once
#include <iostream>
/*
The Texture class is a container for Textures that will be used in the rendering pipeline.
Most of the code for this came from TheChernoProject's OpenGL tutorial series, though I made some modifications.
*/
class Texture
{
private:
	unsigned int m_RendererID;
	std::string m_FilePath;
	unsigned char* m_LocalBuffer;
	int m_Width, m_Height, m_BPP;
public:
	/*
	Creates a Texture object specified by the string path
	*/
	Texture(const std::string& path);
	/*
	Used for shadow rendering, needs refinement.
	*/
	Texture(unsigned int & j);
	/*
	Removes the texture from the program.
	*/
	~Texture();
	/*
	Binds a Texture in slot texture unit for rendering.
	*/
	void Bind(unsigned int slot = 0) const;
	/*
	Unbind a Texture from a texture unit.
	*/
	void UnBind() const;

	/*
	Used for processing for opengl.
	*/
	inline int GetWidth() const { return m_Width; }
	/*
	Used for processing for opengl.
	*/
	inline int GetHeight() const { return m_Height; }
};