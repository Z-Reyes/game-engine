//#include <GL/glew.h>
#include "Render_Manager.h"
#include <GLFW/glfw3.h>
#include <iostream>
#include "Z_Math.h"
#include "Memory_Manager.h"
#include <chrono>
#include "Shader.h"
#include "Camera.h"
#include "Renderable_Shape.h"
#include "Stationary_Object.h"
#include "vendor/AL/al.h"
#include "vendor/AL/alc.h"
#include "Light.h"
#include "PhysicsManager.h"
#include "AudioSource.h"
#include "AudioManager.h"

//Animation_Based Includes

#include "Animation\Animated_Model.h"
#include "Animation\Animation.h"
#include "Animation\Animator.h"
#include "Animation\Joint.h"
#include "Animation\JointTransform.h"
#include "Animation\KeyFrame.h"

//End Animation_Based Includes

#include "Material.h"
#include <cstdlib>
#include <Windows.h>


double xposl = 640;
double yposl = 360;
bool isClicked = false;

void PollKeyEvents(GLFWwindow* window) {
	float moveRate = 0.05f;
	float turnRate = 0.05f;
	int horizontal_strafe_pos = glfwGetKey(window, GLFW_KEY_D);
	int horizontal_strafe_neg = glfwGetKey(window, GLFW_KEY_A);
	int vertical_strafe_pos = glfwGetKey(window, GLFW_KEY_E);
	int vertical_strafe_neg = glfwGetKey(window, GLFW_KEY_Q);
	int depth_strafe_neg = glfwGetKey(window, GLFW_KEY_W);
	int depth_strafe_pos = glfwGetKey(window, GLFW_KEY_S);
	int mouseDown = glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT);

	if (horizontal_strafe_pos == GLFW_PRESS || horizontal_strafe_pos == GLFW_REPEAT) {
		Camera::incX = -moveRate;
	}
	else if (horizontal_strafe_neg == GLFW_PRESS || horizontal_strafe_neg == GLFW_REPEAT) {
		Camera::incX = moveRate;
	}
	else {
		Camera::incX = 0.0f;
	}

	if (vertical_strafe_pos == GLFW_PRESS || vertical_strafe_pos == GLFW_REPEAT) {
		Camera::incY = moveRate;
	}
	else if (vertical_strafe_neg == GLFW_PRESS || vertical_strafe_neg == GLFW_REPEAT) {
		Camera::incY = -moveRate;
	}
	else {
		Camera::incY = 0.0f;
	}

	if (depth_strafe_pos == GLFW_PRESS || depth_strafe_pos == GLFW_REPEAT) {
		Camera::incZ = -moveRate;
	}
	else if (depth_strafe_neg == GLFW_PRESS || depth_strafe_neg == GLFW_REPEAT) {
		Camera::incZ = moveRate;
	}
	else {
		Camera::incZ = 0.0f;
	}
	//if (mouseDown == GLFW_PRESS && mouseDown != GLFW_REPEAT) {
	//	isClicked = true;
	//}
}
//Taken from https://www.glfw.org/docs/latest/input_guide.html
void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS) {
		isClicked = true;
	}
}
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	float moveRate = 0.05f;
	float turnRate = 0.05f;

	//std::cout << "We'ved received a value!" << std::endl;
	if ((key == GLFW_KEY_W || key == GLFW_KEY_S) && (action == GLFW_PRESS || action == GLFW_REPEAT)) {
		if (key == GLFW_KEY_W) {
			Camera::incZ = moveRate;
		}
		else if (key == GLFW_KEY_S) {
			Camera::incZ = -moveRate;
		}

	}
	else {
		Camera::incZ = 0.0f;
	}
	int horizontal_strafe_pos = glfwGetKey(window, GLFW_KEY_D);
	int horizontal_strafe_neg = glfwGetKey(window, GLFW_KEY_A);
	if ((horizontal_strafe_pos == GLFW_PRESS || horizontal_strafe_neg == GLFW_PRESS) && (action == GLFW_PRESS || action == GLFW_REPEAT)) {
		if (horizontal_strafe_pos == GLFW_PRESS || horizontal_strafe_pos == GLFW_REPEAT) {
			Camera::incX = -moveRate;
		}
		else if (horizontal_strafe_neg == GLFW_PRESS || horizontal_strafe_neg == GLFW_REPEAT) {
			Camera::incX = moveRate;
		}

	}
	else {
		Camera::incX = 0.0f;
	}

	if ((key == GLFW_KEY_Q || key == GLFW_KEY_E) && (action == GLFW_PRESS || action == GLFW_REPEAT)) {
		if (key == GLFW_KEY_Q) {
			Camera::incY = -moveRate;
		}
		else if (key == GLFW_KEY_E) {
			Camera::incY = moveRate;
		}

	}
	else {
		Camera::incY = 0.0f;
	}
	if ((key == GLFW_KEY_UP || key == GLFW_KEY_DOWN) && (action == GLFW_PRESS || action == GLFW_REPEAT)) {
		if (key == GLFW_KEY_UP) {
			Camera::rX = -turnRate;
		}
		else if (key == GLFW_KEY_DOWN) {
			Camera::rX = turnRate;
		}

	}
	else {
		Camera::rX = 0.0f;
	}

	if ((key == GLFW_KEY_RIGHT || key == GLFW_KEY_LEFT) && (action == GLFW_PRESS || action == GLFW_REPEAT)) {
		if (key == GLFW_KEY_RIGHT) {
			Camera::rY = -turnRate;
		}
		else if (key == GLFW_KEY_LEFT) {
			Camera::rY = turnRate;
		}

	}
	else {
		Camera::rY = 0.0f;
	}

}

void mouse_position_callback(GLFWwindow * window, double xpos, double ypos) {
	int deadzone = 3;

	float xoff = xpos - xposl;
	
	float yoff = ypos - yposl;
	if (xoff > 0 && xoff < deadzone) {
		xoff = 0;
	}
	else if (xoff < 0 && xoff > -deadzone) {
		xoff = 0;
	}
	if (yoff < deadzone && yoff > 0) {
		yoff = 0;
	}
	else if (yoff > -deadzone && yoff < 0) {
		yoff = 0;
	}
	//std::cout << xoff << " " << yoff << std::endl;

	xposl = xpos;
	yposl = ypos;
	float turnRate = 0.005f;

	Camera::rY = -xoff * turnRate;
	Camera::rX = yoff * turnRate;
}







typedef std::chrono::high_resolution_clock Clock;
/*
AUTHOR:Zachary Reyes
*/

int main() {

	AudioManager * am = CreateStaticAM();
	am->Startup();
	/*
	am->InsertAudio("LC", "res/Sounds/FB_LC.wav");
	AudioSource* leftChannel = am->GetAudioWithId("LC");
	leftChannel->SetVelocity(0.0f, 0.0f, 0.0f);
	leftChannel->SetLooping(true);
	leftChannel->SetPosition(-5.0f, 0.0f, -10.0f);

	am->InsertAudio("RC", "res/Sounds/FB_RC.wav");
	AudioSource * rightChannel = am->GetAudioWithId("RC");
	rightChannel->SetLooping(true);
	rightChannel->SetPosition(5.0f, 0.0f, -10.0f);
	rightChannel->SetVelocity(0.0f, 0.0f, 0.0f);
	*/
	ALfloat listenerOri[] = { 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f };

	

	am->InsertAudio("bells", "res/Sounds/bell_toll.wav");
	AudioSource* one = am->GetAudioWithId("bells");
	one->SetLooping(true);
	one->SetPitch(1.0f);
	one->SetGain(15.0f);
	//one->SetMaxDistance(5.0f);
	//one->SetFallOffFactor(100.0f);
	//one->ForceMaximumMaxDistance();
	one->SetPosition(70.0f, 45.0f, -45.0f);
	one->SetVelocity(0.0f, 0.0f, 0.0f);
	one->SetMinDistance(1.0f);
	one->SetMaxGain(1.0f);
	one->SetMinGain(0.0001f);
	one->PlayAudio();


	am->InsertAudio("meadowlark", "res/Sounds/meadowlark_mono.wav");
	one = am->GetAudioWithId("meadowlark");
	one->SetLooping(true);
	one->SetPitch(1.0f);
	one->SetGain(0.65f);
	one->SetPosition(-50.0f, 10.0f, -15.0f);
	one->SetVelocity(0.0f, 0.0f, 0.0f);
	one->SetMaxGain(1.0f);
	one->SetMinGain(0.0001f);
	one->PlayAudio();

	am->InsertAudio("saudade", "res/Sounds/saudade.wav");
	one = am->GetAudioWithId("saudade");
	one->SetLooping(true);
	one->SetPitch(1.f);
	one->SetGain(0.1f);
	//one->SetPosition(-50.0f, 10.0f, -15.0f);
	//one->SetVelocity(0.0f, 0.0f, 0.0f);
	//one->SetMaxGain(1.0f);
	//one->SetMinGain(0.0001f);
	one->PlayAudio();

	alListener3f(AL_POSITION, 0.0, 0, 0.0f);
	// check for errors
	alListener3f(AL_VELOCITY, 0, 0, 0);
	// check for errors
	alListenerfv(AL_ORIENTATION, listenerOri);





	std::cout << "Starting program << " << std::endl;
	GLFWwindow* window;
	/* Initialize the library */
	if (!glfwInit()) {
		std::cout << "Problem with initialization" << std::endl;
		return -1;
	}


	//glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	//glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	//glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	/* Create a windowed mode window and its OpenGL context */
	window = glfwCreateWindow(1280, 720, "Project OpenGL", NULL, NULL);



	if (!window)
	{
		std::cout << "Problem with window" << std::endl;
		glfwTerminate();
		return -1;
	}

	/* Make the window's context current */
	glfwMakeContextCurrent(window);
	glfwSwapInterval(1);
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);
	glfwSetCursorPosCallback(window, mouse_position_callback);
	//Taken from https://www.glfw.org/docs/latest/input_guide.html
	glfwSetMouseButtonCallback(window, mouse_button_callback);
	GLCall(glEnable(GL_DEPTH_TEST));
	if (glewInit() != GLEW_OK) {
		std::cout << "Error boi" << std::endl;
	}

	MemoryManager* mm1 = CreateStaticMM();


	mm1->StartUp(1,1,1,1);

	



	Camera bbCam;



	Zat4 P = OpenGlPerspective(45.0f, 0.1f, 1000.0f, 16.0f / 9.0f);
	std::cout << "Built perspective matrix" << std::endl;
	float deltaRotation = 0.0f;
	float distance = -1.0f;
	bool backMode = true;
	Zat4 yRotation = Zat4(1.0f);
	Zat4 scale = Zat4(1.0f, 0.5f, 1.0f);
	Zat4 translation = Translate(0.0f, 0.0f, -1.0f);
	float zoomModifier = 0.0f;

	RenderManager* rm = CreateStaticRM();
	rm->Startup();
	mm1->AddTexture("res/Textures/sky3.jpg", "sky");
	mm1->AddTexture("res/Textures/stone.jpg", "stone");
	mm1->AddTexture("res/Textures/ss.jpg", "shenoi");
	mm1->AddTexture("res/Textures/mailler.jpg", "mailler");
	mm1->AddTexture("res/Textures/orange_tex.jpg", "orange");
	mm1->AddTexture("res/Textures/Banana.jpg", "car");
	mm1->AddTexture("res/Textures/JJ.png", "joseph");
	mm1->AddModel("res/Models/Banana.obj", "anime", true);
	mm1->AddModel("res/Models/BigBen/10059_big_ben_v2_max2011_it1.obj", "clocktower", true);
	mm1->AddTexture("res/Textures/grass.png", "grass");
	mm1->AddModel("res/Models/Zachodel.obj", "zach", true);
	mm1->AddTexture("res/Textures/Zachodel.png", "zach");
	mm1->AddTexture("res/Textures/sky_map.jpg", "skysphere");
	mm1->AddTexture("res/Textures/wood.jpg", "wood");
	mm1->AddTexture("res/Textures/Dice.jpg", "dice");

	mm1->AddModel("res/Models/house/house.obj", "House",true);
	mm1->AddTexture("res/Textures/house-low-texture.jpg", "house");
	Stationary_Object* test = new Stationary_Object(5.0f, -8.0f, -5.0f, 3);
	
	test->SetShapeID("Quad");
	
	test->SetTexID("shenoi");
	Stationary_Object* test2 = new Stationary_Object(-10.0f, -8.0f, -5.0f, 3);
	Stationary_Object* pyramid = new Stationary_Object(-5.0f, -8.0f, -5.0f, 2);
	Stationary_Object* orange = new Stationary_Object(45.0f, 2.5f, -15.0f, 3);
	Stationary_Object* objectFileTest = new Stationary_Object(10.0f, -8.5f, -5.0f, 2);
	Stationary_Object* cube2 = new Stationary_Object(45.0f, 0.0f, -5.0f, 3);
	Stationary_Object* cube3 = new Stationary_Object(45.0f, 0.0f, 0.0f, 3);
	Stationary_Object* clocktower = new Stationary_Object(70.0f, -10.0f, -45.0f, 3);
	Stationary_Object* zachModel = new Stationary_Object(0.0f, -8.0f, -5.0f, 2);
	zachModel->SetRotation(Zec3(1.0f, 0.0f, 0.0f), 3.14 / 2);
	//zachModel->SetRotation();
	Stationary_Object* skyFrame = new Stationary_Object(0.0f, 0.0f, 0.0f, 2);
	Stationary_Object* soccerball = new Stationary_Object(0.0f, 0.0f, 0.0f, 3);
	Stationary_Object* house1 = new Stationary_Object(-15.0f, -8.5f, 0.0f, 2);
	house1->SetShapeID("House");
	house1->SetTexID("house");
	house1->SetScale(0.025f, 0.025f, 0.025f);
	Stationary_Object* house2 = new Stationary_Object(30.0f, -8.5f, 0.0f, 3);
	house2->SetShapeID("House");
	house2->SetTexID("house");
	house2->SetScale(0.025f, 0.025f, 0.025f);
	Stationary_Object* house3 = new Stationary_Object(30.0f, -8.5f, 50.0f, 3);
	house3->SetShapeID("House");
	house3->SetTexID("house");
	house3->SetScale(0.025f, 0.025f, 0.025f);
	Stationary_Object* house4 = new Stationary_Object(-15.0f, -8.5f, 50.0f, 3);
	house4->SetShapeID("House");
	house4->SetTexID("house");
	house4->SetScale(0.025f, 0.025f, 0.025f);
	soccerball->SetShapeID("Sphere");
	soccerball->friction = 0.25;
	soccerball->mass = 1.0f;
	soccerball->restitution = 0.5f;
	skyFrame->SetShapeID("Sphere");
	skyFrame->SetTexID("skysphere");
	rm->SetSkyFrame(skyFrame);
	clocktower->SetShapeID("clocktower");
	zachModel->SetShapeID("zach");
	zachModel->SetTexID("zach");
	zachModel->SetScale(3.0f, 3.0f, 3.0f);
	cube2->SetTexID("dice");
	cube3->SetTexID("sky");
	//objectFileTest->SetRotation(Zec3(1.0f, 0.0f, 0.0f), 3.14/2);
	
	objectFileTest->SetShapeID("anime");
	objectFileTest->SetTexID("car");
	//objectFileTest->SetTexID("joseph");
	objectFileTest->SetScale(0.006f, 0.006f, 0.006f);
	orange->SetShapeID("Sphere");
	
	orange->SetTexID("stone");
	
	pyramid->SetShapeID("Pyramid");
	
	pyramid->SetTexID("mailler");
	clocktower->SetScale(0.01f, 0.01f, 0.01f);
	clocktower->SetRotation(Zec3(1.0f, 0.0f, 0.0f), 3.14 / 2);
	rm->SetProjectionMatrix(P);
	rm->AppendOpaqueRenderQueue(test);
	rm->AppendOpaqueRenderQueue(test2);
	rm->AppendOpaqueRenderQueue(orange);
	rm->AppendOpaqueRenderQueue(pyramid);
	rm->AppendOpaqueRenderQueue(cube3);
	rm->AppendOpaqueRenderQueue(objectFileTest);
	rm->AppendOpaqueRenderQueue(zachModel);
	rm->AppendOpaqueRenderQueue(clocktower);
	rm->AppendOpaqueRenderQueue(soccerball);
	rm->AppendOpaqueRenderQueue(house1);
	rm->AppendOpaqueRenderQueue(house2);
	rm->AppendOpaqueRenderQueue(house3);
	rm->AppendOpaqueRenderQueue(house4);
	soccerball->SetTexID("wood");
	/*
	MATERIAL AND LIGHT STUFF.
	*/
	light *testLightDirection = new light();
	testLightDirection->myType = directional;
	testLightDirection->SetAura(0.02f, 0.02f, 0.02f);
	testLightDirection->SetAmbient(0.02f, 0.02f, 0.02f);
	testLightDirection->SetDiffuse(0.1f, 0.1f, 0.1f);
	testLightDirection->SetSpecular(0.02f, 0.02f, 0.02f);
	testLightDirection->identifier = 1;
	testLightDirection->SetPosition(0.0f, -1.0f, -1.0f); //Directional light's position IS direction.
	rm->AppendLightQueue(testLightDirection);
	light *testLight = new light();
	testLight->myType = positional;
	//light testLight;
	
	testLight->SetAura(0.05f, 0.05f, 0.05f);
	testLight->SetAmbient(0.05f, 0.05f, 0.05f);
	testLight->SetDiffuse(7.05f, 7.05f, 0.05f);
	testLight->SetSpecular(0.05f, 0.05f, 0.05f);
	testLight->identifier = 0;
	testLight->SetPosition(65.0f, 45.0f, -45.0f);
	testLight->linear = 0.18f;
	testLight->constant = 1.0f;
	testLight->quadratic = 0.07f;
	//std::cout << "Test light's new position is " << testLight->position[2] << std::endl;
	//std::cout << "Test light's new value is " << testLight->specularLight[0] << std::endl;
	rm->AppendLightQueue(testLight);
	
	light *testLight2 = new light();
	testLight2->myType = positional;
	//light testLight;

	testLight2->SetAura(0.05f, 0.05f, 0.05f);
	testLight2->SetAmbient(0.05f, 0.05f, 0.05f);
	testLight2->SetDiffuse(1.05f, 1.05f, 0.05f);
	testLight2->SetSpecular(1.05f, 1.05f, 0.05f);
	testLight2->identifier = 0;
	testLight2->SetPosition(-22.5f, -4.75f, 0.0f);
	testLight2->linear = 0.18f;
	testLight2->constant = 1.0f;
	testLight2->quadratic = 0.07f;
	testLight2->myType = positional;
	rm->AppendLightQueue(testLight2);
	//rm->AppendLightQueue(testLight);
	//rm->AppendLightQueue(testLight2);
	testLight2 = new light();

	testLight2->SetAura(0.05f, 0.05f, 0.05f);
	testLight2->SetAmbient(0.05f, 0.05f, 0.05f);
	testLight2->SetDiffuse(0.05f, 0.05f, 7.05f);
	testLight2->SetSpecular(0.05f, 0.05f, 7.05f);
	testLight2->identifier = 0;
	testLight2->SetPosition(25.0f, -4.0f, 25.0f);
	testLight2->linear = 0.18f;
	testLight2->constant = 1.0f;
	testLight2->quadratic = 0.07f;
	testLight2->myType = positional;
	rm->AppendLightQueue(testLight2);

	testLight2 = new light();

	testLight2->SetAura(0.05f, 0.05f, 0.05f);
	testLight2->SetAmbient(0.05f, 0.05f, 0.05f);
	testLight2->SetDiffuse(1.05f, 1.05f, 1.05f);
	testLight2->SetSpecular(2.05f, 2.05f, 2.05f);
	testLight2->identifier = 0;
	testLight2->SetPosition(-15.0f, -4.0f, 25.0f);
	testLight2->linear = 0.18f;
	testLight2->constant = 1.0f;
	testLight2->quadratic = 0.07f;
	testLight2->myType = positional;
	rm->AppendLightQueue(testLight2);

	material myMat2;
	myMat2.SetAmbient(0.1f, 0.18725f, 0.1745f, 0.8f);
	myMat2.SetDiffuse(0.396f, 0.74151f, 0.69102f, 0.8f);
	myMat2.SetSpecular(0.297254f, 0.30829f, 0.306678f, 0.8f);
	myMat2.SetShiny(12.8f);
	
	material myMat;
	
	myMat.SetAmbient(0.135f, 0.2225f, 0.1575f, 0.95f);
	myMat.SetDiffuse(0.54f, 0.89f, 0.63f, 0.95f);
	myMat.SetSpecular(0.3162f, 0.3162f, 0.3162f, 0.95f);//alpha values should be 0.95f
	myMat.SetShiny(12.8f);

	material myMat3;
	myMat3.SetAmbient(0.05f, 0.3f, 0.05f, 1.0f);
	myMat3.SetDiffuse(1.0f, 2.0f, 1.0f, 1.0f);
	myMat3.SetSpecular(0.05f, 0.05f, 0.05f, 1.0f);
	myMat3.SetShiny(1.f);
	//std::cout << "My mat's shininess is " << myMat.ambient[0] << std::endl;
	orange->SetMyMaterial(myMat);
	objectFileTest->SetMyMaterial(myMat2);
	test->SetMyMaterial(myMat2);
	test2->SetMyMaterial(myMat3);
	cube2->SetMyMaterial(myMat);
	cube3->SetMyMaterial(myMat);

	//Physics startup
	PhysicsManager * pm = CreateStaticPM();
	pm->StartUp();
	soccerball->SetScale(0.5f, 0.5f, 0.5f);
	pm->InsertRigidBody(soccerball, Sphere);
	orange->SetScale(1.5f, 1.5f, 1.5f);
	//orange->SetPosition(0.0f, 10.0f, 0.0f);
	orange->mass = 15.0f;
	//orange->SetPosition(0.0f, 10.0f, 0.0f);
	pm->InsertRigidBody(orange, Sphere);
	test2->mass = 0.0f;
	test2->SetTexID("grass");
	test2->SetPosition(0.0f, -10.0f, 0.0f);
	test2->SetScale(100.0f, 1.5f, 100.0f);
	pm->InsertRigidBody(test2, Cube);
	pm->InsertRigidBody(cube2, Cube);
	pm->InsertRigidBody(cube3, Cube);
	//orange->usePhysics = false;
	//test2->usePhysics = false;
	//cube2->usePhysics = false;
	std::vector<RendereableObject*> UpdateQueue;
	UpdateQueue.push_back(orange);
	UpdateQueue.push_back(test2);
	UpdateQueue.push_back(cube2);
	UpdateQueue.push_back(cube3);
	UpdateQueue.push_back(soccerball);
	rm->AppendOpaqueRenderQueue(cube2);

	
	//Let's do animations now!
	//First, we need our list of vertices and weights:
	float *quadra = new float[36]
	{-1.0f,1.0f,0.0f,
		1.0f, 0.0f,0.0f,
	0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
	1.0f, 1.0f, 0.0f,
		0.0f, 0.0f, 1.0f,
	-1.0f, -1.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
	0.0, -1.0f, 0.0f,
		0.0f,1.0f,0.0f,
	1.0f, -1.0f, 0.0f,
		0.0f,0.0f,1.0f};
	unsigned int quadraSize = 36;

	unsigned int* quadraIndices = new unsigned int[12]
	{
	0,3,1,
	3,4,1,
	1,4,2,
	4,5,2
	};
	unsigned int quadraVertices = 12;

	unsigned int* quadraJointsUse = new unsigned int[18]
	{0,1,2,
	0,1,2,
	0,1,2,
	0,1,2,
	0,1,2,
	0,1,2};
	unsigned int quadraJointNum = 18;

	RenderableShape*  quadraShape = new RenderableShape(quadra, quadraSize, quadraIndices, quadraVertices, quadraJointsUse, quadraJointNum);
	
	/*
	Next, we set our joints with the bind positions and establish the hierarchy.
	*/
	
	Joint* x1 = new Joint(0, "x1", Translate(-0.5f,0.0f,0.0f));
	Joint* x2 = new Joint(1, "x2", Translate(0.0f, 0.0f, 0.0f));
	Joint* x3 = new Joint(2, "x3", Translate(0.5f, 0.0f, 0.0f));

	x1->SetInverseBindTransform(Translate(0.5f, 0.0f, 0.0f));
	x2->SetInverseBindTransform(Zat4(1.0f));
	x3->SetInverseBindTransform(Translate(-0.5f, 0.0f, 0.0f));


	x2->AddChild(x1);
	x2->AddChild(x3);
	
	/*
	Next, we create the KeyFrames for each joint.
	*/
	
	std::unordered_map<std::string, JointTransform*> quadraJT;
	JointTransform* x1StartTransform = new JointTransform(Zec3(-0.5f,0.0f,0.0f), Quaternion());
	JointTransform* x2StartTransform = new JointTransform(Zec3(0.0f, 0.0f, 0.0f), Quaternion());
	JointTransform* x3StartTransform = new JointTransform(Zec3(0.5f, 0.0f, 0.0f), Quaternion());
	quadraJT.insert({"x1", x1StartTransform});
	quadraJT.insert({ "x2", x2StartTransform });
	quadraJT.insert({ "x3", x3StartTransform });
	KeyFrame initialPose(0.0f, quadraJT);

	std::unordered_map<std::string, JointTransform*> quadraJT2;
	JointTransform* x1EndTransform = new JointTransform(Zec3(-2.5f, 1.0f, -1.0f), Quaternion());
	JointTransform* x2EndTransform = new JointTransform(Zec3(0.0f, 0.0f, 0.0f), Quaternion());
	JointTransform* x3EndTransform = new JointTransform(Zec3(2.5f, -1.0f, 1.0f), Quaternion(0.0f, 0.71f, 0.0f, 0.71f));
	//0.0f, 0.71f, 0.0f, 0.71f
	quadraJT2.insert({ "x1", x1EndTransform });
	quadraJT2.insert({ "x2", x2EndTransform });
	quadraJT2.insert({ "x3", x3EndTransform });
	KeyFrame finalPose(5.0f, quadraJT2);
	
	/*
	Now, we create the animation for the whole blasted thing.
	*/
	
	std::vector<KeyFrame> quadraFrames;
	quadraFrames.push_back(initialPose);
	quadraFrames.push_back(finalPose);
	Animation quadAnimation(5.0f, quadraFrames);

	//Link our model, we use x2 as our root.
	Animated_Model quadraModel(quadraShape, "null", x2, 3);

	Animator quadraAnimator(&quadraModel);
	quadraAnimator.doAnimation(&quadAnimation);

	//quadraAnimator.UpdateAnimation();
	//leftChannel->PlayAudio();
	//rightChannel->PlayAudio();
	alListenerf(AL_GAIN, 0.5);
	//
	typedef std::chrono::nanoseconds sec;
	typedef std::chrono::duration<float> fseconds;
	float deltaTime = 1.0f / 60.0f;
	auto initialTime = Clock::now();
	auto endTime = Clock::now();
	//auto endTime = td::chrono::duration_cast<std::chrono::milliseconds>(endtime - startTest).count()
	while (!glfwWindowShouldClose(window)) {
		fseconds delta = endTime - initialTime;
		sec deltaT = std::chrono::duration_cast<sec>(delta);
		//std::cout << "Our time in seconds is " << deltaT.count() << std::endl;
		deltaTime = 0.000000001 * deltaT.count();
		initialTime = Clock::now();
		PollKeyEvents(window);
		bbCam.AssignAllChanges();
		Position_Bag* newPos = bbCam.GetCameraLocation().GetPosition();
		Position_Bag* forwardCam = bbCam.GetForwardVector().GetDirection();
		Position_Bag* upCam = bbCam.GetUpVector().GetDirection();
		//std::cout << "x is " << -newPos->location[0] << " y is " << -newPos->location[1] << " z is " << -newPos->location[2] << std::endl;
		alListener3f(AL_POSITION, -newPos->location[0], -newPos->location[1], -newPos->location[2]);
		listenerOri[0] = (ALfloat)forwardCam->location[0];
		listenerOri[1] = (ALfloat)forwardCam->location[1];
		listenerOri[2] = (ALfloat)forwardCam->location[2];

		listenerOri[3] = (ALfloat)upCam->location[0];
		listenerOri[4] = (ALfloat)upCam->location[1];
		listenerOri[5] = (ALfloat)upCam->location[2];

		alListenerfv(AL_ORIENTATION, listenerOri);

		if (isClicked) {
		//	std::cout << "I've detected a click" << std::endl;
			isClicked = false;
			soccerball->SetPosition(-newPos->location[0], -newPos->location[1], -newPos->location[2]);
			soccerball->initialForce = Position_Bag(-30 * forwardCam->location[0], -30 * forwardCam->location[1], -30 * forwardCam->location[2], forwardCam->location[3]);
			soccerball->ForceObjectPositionOnPhysics();
		}

		/*
		Apply update
		*/
		//orange->myBody->applyCentralForce(btVector3(1.0f, 0.0f, 0.0f));
		
		pm->UpdateWorld(deltaTime);
		for (int i = 0; i < UpdateQueue.size(); i++) {
			UpdateQueue.at(i)->OnUpdate();
		}



		rm->DrawOpaqueRenderQueue();

		quadraAnimator.UpdateAnimation(deltaTime);

		rm->RenderAnimatedObject(quadraShape, quadraModel.GetJointTransforms(), quadraModel.GetJointCount());

		glfwSwapBuffers(window);

		glfwPollEvents();

		endTime = Clock::now();
	}
	mm1->Shutdown();
	rm->Shutdown();
	pm->Shutdown();
	am->Shutdown();
	//std::cin;
	glfwTerminate();
	return 0;
}