#pragma once
#include "Renderable_Object.h"
/*
A testing behavior class simply for the purposes of milestone 2. Creates a stationary object at a 
given starting location
*/
class Stationary_Object : public RendereableObject {
public:
	Stationary_Object();
	/*
	Creates a Stationary_Object at position x, y, z, with dt desired rendering tier.
	*/
	Stationary_Object(float x, float y, float z, unsigned int dt);
	/*
	Does nothing.
	*/
	void OnUpdate();
};